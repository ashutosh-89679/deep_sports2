<?php
// Define the database connection details
include 'ladderDb.php';


header("Access-Control-Allow-Origin: *");


// Create a database connection using PDO
try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}


// Construct the SQL query
$sql = "
SELECT
    project_id AS id, project_name  AS name FROM project";

// Execute the SQL query
$result = $pdo->query($sql);

if ($result) {
    $data = $result->fetchAll(PDO::FETCH_ASSOC);

    // Output the data as JSON
    echo json_encode($data);
} else {
    echo "Error: " . $sql;
}

// Close the database connection
$pdo = null;
?>
