<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$dbHost = 'localhost';
$dbUsername = "aarnainw_ashutosh";
$dbPassword = "4PtX8dn]&m!-";
$dbName = "aarnainw_finance_main";

// Function to establish a database connection
function connectToDatabase() {
    global $dbHost, $dbUsername, $dbPassword, $dbName;
    $conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}
//ALL THE FUNCTIONS

function calculatePercentage($numerator, $denominator) {
    if ($denominator  == 0) {
        return 0; 
    }
    $percentage = ($numerator / $denominator) * 100;
    return $percentage;
}

function calculateAverage($numbers) {
    $count = count($numbers);
    
    if ($count === 0) {
        return 0; 
    }
    
    $sum = array_sum($numbers);
    $average = $sum / $count;
    
    return $average;
}

function calculateRealizedAmount($av , $brokerage , $cashback_amount) {
    $invoice_value = $av * $brokerage;
    $GST = 18;
    $GST_amount = $invoice_value * ($GST / 100);
    $total_invoice_amount = $invoice_value + $GST_amount;
    $Tds = 5;
    $TDS_deducted = $invoice_value * ($Tds / 100);
    $realized_amount = $total_invoice_amount - $TDS_deducted - $cashback_amount;
    return $realized_amount;
}



$json_data = file_get_contents('php://input');

$data = json_decode($json_data, true);



function getData($data) {
    global $conn;

    $result = array();
    $start_date = null;
    $end_date = null;

    if (isset($data['start_date'])) {
        $start_date = $data['start_date'];
    }

    if (isset($data['end_date'])) {
        $end_date = $data['end_date'];
    }

    $locationQuery = "SELECT DISTINCT location_id, location_name FROM location";
    $locationResult = $conn->query($locationQuery);

    while ($locationRow = $locationResult->fetch_assoc()) {
        $locationId = $locationRow['location_id'];
        $location_name = $locationRow['location_name'];

        $developerQuery = "SELECT DISTINCT developer_id, developer_name FROM developer WHERE location_id = $locationId";
        $developerResult = $conn->query($developerQuery);

        while ($developerRow = $developerResult->fetch_assoc()) {
            $developerId = $developerRow['developer_id'];
            $developer_name = $developerRow['developer_name'];

            $companyQuery = "SELECT DISTINCT company_id, company_name FROM company WHERE developer_id = $developerId";
            $companyResult = $conn->query($companyQuery);

            while ($companyRow = $companyResult->fetch_assoc()) {
                $companyId = $companyRow['company_id'];
                $company_name = $companyRow['company_name'];

                $projectQuery = "SELECT DISTINCT project_id, project_name FROM project WHERE company_id = $companyId";
                $projectResult = $conn->query($projectQuery);

                while ($projectRow = $projectResult->fetch_assoc()) {
                    $projectId = $projectRow['project_id'];
                    $project_name = $projectRow['project_name'];

                    $basic_detail_array = array();

                    if ($projectId !== null) {
                        if ($start_date === null || $end_date === null) {
                            $basic_sql = "SELECT
                            bd.closure_date,
                            SUM(CASE WHEN i.post_raise_id != 4 THEN bd.agreement_value ELSE 0 END) AS net_revenue_sale,
                            SUM(bd.agreement_value) AS gross_sale,
                            SUM(CASE WHEN i.post_raise_id != 4 THEN bd.cashback_amount ELSE 0 END) AS net_revenue_cashback,
                            SUM(bd.cashback_amount) AS gross_cashback
                        FROM
                            booking_details bd
                            JOIN invoice i ON bd.client_id = i.client_id
                        WHERE
                            bd.project_id = '$projectId'";
                        }
                        else {
                            $basic_sql = "SELECT
                                        bd.closure_date,
                                        SUM(CASE WHEN i.post_raise_id != 4 THEN bd.agreement_value ELSE 0 END) AS net_revenue_sale, 
                                        SUM(bd.agreement_value) AS gross_sale,
                                        SUM(CASE WHEN i.post_raise_id != 4 THEN bd.cashback_amount ELSE 0 END) AS net_revenue_cashback,
                                        SUM(bd.cashback_amount) AS gross_cashback
                                    FROM
                                        booking_details bd
                                        JOIN invoice i ON bd.client_id = i.client_id
                                    WHERE
                                    bd.project_id = '$projectId' AND bd.closure_date BETWEEN '$start_date' AND '$end_date'";
                        }                        
                        $basic_sql_result = $conn->query($basic_sql);

                        while ($basicDetailRow = $basic_sql_result->fetch_assoc()) {
                            $total_sale = $basicDetailRow['gross_sale'];
                            $closure_date = $basicDetailRow['closure_date'];
                            $cashback_amount = $basicDetailRow['gross_cashback'];
                            $net_revenue_sale = $basicDetailRow['net_revenue_sale'];
                            $net_revenue_cashback = $basicDetailRow['net_revenue_cashback'];

                            $basic_detail_entry = array(
                                "name" => $project_name,
                                "total_sale" => $total_sale,
                                "borkerage_percent" => null,
                                "avg_brokerage"=>null,
                                "Realized_Amount" => null,
                                "Net_Revenue" => null,
                                "Gross_revenue" => null,
                                "cashback" => $cashback_amount
                            );

                            $ladder_id_sql = "SELECT ladder_id AS fectched_ladder_id FROM project_ladder WHERE project_id = $projectId";
                            $result_ladder_id = $conn->query($ladder_id_sql);

                            if ($result_ladder_id) {
                                while ($ladder_id_row = $result_ladder_id->fetch_assoc()) {
                                    $fetched_ladder_id = $ladder_id_row['fectched_ladder_id'];
                                    if ($fetched_ladder_id) {
                                        $ladder_percent = "SELECT stage_percent AS ladder_percent
                                        FROM ladder
                                        WHERE ladder_start_date <= '$closure_date'
                                        AND ladder_end_date >= '$closure_date'
                                        AND ladder_id = '$fetched_ladder_id'
                                        AND (
                                            SELECT COUNT(project_id) 
                                            FROM booking_details
                                            WHERE project_id = '$projectId'
                                            AND ladder_stage_start <= (
                                                SELECT COUNT(project_id)
                                                FROM booking_details
                                                WHERE project_id = '$projectId'
                                            )
                                            AND ladder_stage_end >= (
                                                SELECT COUNT(project_id)
                                                FROM booking_details
                                                WHERE project_id = '$projectId'
                                            )
                                        )
                                        ";
                                        $result_ladder_percent = $conn->query($ladder_percent);
                                        if ($result_ladder_percent) {
                                            while ($ladder_percent_row = $result_ladder_percent->fetch_assoc()) {
                                                $basic_detail_entry["ladder_percent"] = $ladder_percent_row['ladder_percent'];
                                                $basic_detail_entry["Realized_Amount"] = calculateRealizedAmount($total_sale, $ladder_percent_row['ladder_percent'], $cashback_amount);
                                                $basic_detail_entry["Gross_revenue"]= calculateRealizedAmount($total_sale, $ladder_percent_row['ladder_percent'], $cashback_amount);
                                                $basic_detail_entry["Net_Revenue"]= calculateRealizedAmount($net_revenue_sale, $ladder_percent_row['ladder_percent'], $net_revenue_cashback);
                                            }
                                        }
                                    }
                                    if ($fetched_ladder_id) {
                                        $ladder_percent2 = "SELECT stage_percent AS brokerage_percent FROM `ladder` WHERE  ladder_stage = 0 AND ladder_id = '$fetched_ladder_id'";
                                        $result_ladder_percent2 = $conn->query($ladder_percent2);
                                        if ($result_ladder_percent2) {
                                            while ($ladder_percent_row2 = $result_ladder_percent2->fetch_assoc()) {
                                                $basic_detail_entry["brokerage_percent"] = $ladder_percent_row2['brokerage_percent'];
                                                $basic_detail_entry["avg_brokerage"]= $ladder_percent_row2['brokerage_percent'];
                                            }
                                        }
                                    }
                                }
                            }

                            $basic_detail_array[] = $basic_detail_entry;
                        }
                    }

                    $result[] = array(
                        "branch" => $location_name,
                        "id" => $locationId,
                        "developers" => array(
                            array(
                                "id" => $developerId,
                                "name" => $developer_name,
                                "companies" => array(
                                    array(
                                        "name" => $company_name,
                                        "projects" => array(
                                            array(
                                                "name" => $project_name,
                                                "id" => $projectId,
                                                "basic_detail_array" => $basic_detail_array
                                            )
                                        )
                                    )
                                )
                            )
                        )
                    );
                }
            }
        }
    }

    return $result;
}



$conn = connectToDatabase(); 

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

$data = getData($data);

header('Content-Type: application/json');
echo json_encode($data, JSON_PRETTY_PRINT);
?>

