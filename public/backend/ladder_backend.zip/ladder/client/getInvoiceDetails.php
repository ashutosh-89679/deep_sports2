<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'database.php';


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}



$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

function jsonResponse($statusCode, $data)
{
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
}

$client_id = null;

if (isset($data['client_id'])) {
    $client_id = $data['client_id'];
}

if (!empty($client_id)) {

    $sql = "SELECT
    invoice.*,
    company.company_name,
    booked_clients.name
    FROM
        invoice
    JOIN
        company ON invoice.company_id = company.company_id
    JOIN 
        booked_clients ON invoice.client_id = booked_clients.User_id
    WHERE
        invoice.client_id = ?
    ORDER BY
        invoice.invoice_raise_date DESC;";
    
    $stmt = $conn->prepare($sql);

    $stmt->bind_param('s', $client_id);

    if ($stmt->execute()) {
        $result = $stmt->get_result();
        
        // Fetch the data from the result set
        $data = $result->fetch_all(MYSQLI_ASSOC);
        
        jsonResponse(200, ['data' => $data]);
    } else {
        jsonResponse(500, ['error' => 'Failed to execute the query']);
    }
} else {
    jsonResponse(400, ['error' => 'Client_id is empty']);
}
?>
