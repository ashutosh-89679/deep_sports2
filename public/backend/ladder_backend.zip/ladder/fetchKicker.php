<?php
// Database configuration (update with your database credentials)
include 'ladderDb.php';


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}


// Create a database connection using PDO
try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}


$start_date = null;
$end_date = null;
$search_project_id = null;

$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

if (isset($data['search_project_id'])) {
    $search_project_id = $data['search_project_id'];
}

if (isset($data['search_start_date'])) {
    $start_date = $data['search_start_date'];
}

if (isset($data['search_end_date'])) {
    $end_date = $data['search_end_date'];
}

// Query to fetch kicker_ids from project_kicker
$query = "SELECT DISTINCT kicker_id FROM project_kicker ";
$stmt = $pdo->prepare($query);
$stmt->execute();

// Fetch kicker_ids into an array
$kickerIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
$kickerIds = array_unique($kickerIds);

// Construct the SQL query
$sql = "
SELECT
    kl.relation_id AS relationid,
    k.kicker_start_date AS start_date,
    k.kicker_end_date AS end_date,
    k.kicker_extended_date AS extended_date,
    k.Kicker_target_in_amount AS target_amount,
    k.Kicker_target_in_unit AS target_unit,
    k.kicker_condition AS kicker_condition,
    k.kicker_in_percent AS target_percent,
    k.kicker_in_value AS kicker_value,
    kl.kicker_id,
    p.project_name,
    d.developer_name
FROM kicker k
JOIN project_kicker kl ON k.kicker_unique_id = kl.kicker_id
JOIN project p ON kl.project_id = p.project_id
JOIN company c ON p.company_id = c.company_id
JOIN developer d ON c.developer_id = d.developer_id
WHERE k.kicker_unique_id IN ('" . implode("', '", $kickerIds) . "')
";

if (!empty($search_project_id)) {
    $sql .= " AND kl.project_id IN ($search_project_id)";
}

if ($start_date !== null && $end_date !== null) {
    $sql .= " AND ( k.kicker_start_date BETWEEN :start_date AND :end_date
                    OR :start_date AND :end_date BETWEEN k.kicker_start_date AND k.kicker_end_date
                    OR k.kicker_extended_date BETWEEN :start_date AND :end_date)";
}
// Add GROUP BY clause to group by kicker_id
$sql .= " GROUP BY kl.kicker_id, kl.project_id, p.project_name, c.company_id, d.developer_name";

// Add ORDER BY clause to get the most recent kicker_start_date
$sql .= " ORDER BY start_date DESC, end_date DESC";

// Prepare and execute the SQL query with date range parameters
$stmt = $pdo->prepare($sql);
if ($start_date !== null && $end_date !== null) {
    $stmt->bindParam(':start_date', $start_date);
    $stmt->bindParam(':end_date', $end_date);
}
$stmt->execute();

// Fetch and output the data as JSON
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($data);

// Close the database connection
$pdo = null;
?>
