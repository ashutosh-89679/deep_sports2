<?php
// Database configuration (update with your database credentials)
include 'ladderDb.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");


if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}


try {
    // Connect to the database
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);

    // Set PDO to throw exceptions on errors
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if a file was uploaded
    if (isset($_FILES['file'])) {
        $file_name = $_FILES['file']['name'];
        $file_data = file_get_contents($_FILES['file']['tmp_name']);

        // Additional data
        $file_type = $_POST['file_type'];
        $unique_ids = $_POST['unique_id']; 

        // Split the comma-separated project IDs into an array
        $unique_ids_array = explode(',', $unique_ids);

        // Iterate through each project ID and insert the file
        foreach ($unique_ids_array as $unique_id) {
            // Prepare an SQL statement to insert the file data and additional data into the database
            $stmt = $pdo->prepare("INSERT INTO files (file_name, file_data, file_type, unique_id) VALUES (:file_name, :file_data, :file_type, :unique_id)");
            $stmt->bindParam(':file_name', $file_name);
            $stmt->bindParam(':file_data', $file_data, PDO::PARAM_LOB);
            $stmt->bindParam(':file_type', $file_type);
            $stmt->bindParam(':unique_id', $unique_id); 
            // Execute the SQL statement for the current project ID
            if ($stmt->execute()) {
                $response = ['message' => 'File uploaded successfully for Unique ID ' . $unique_id];
            } else {
                $response = ['error' => 'Error uploading file for Project ID ' . $unique_id];
            }
        }
    } else {
        $response = ['error' => 'No file uploaded'];
    }

    // Return a JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
} catch (PDOException $e) {
    $response = ['error' => 'Database error: ' . $e->getMessage()];

    // Return a JSON response
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
