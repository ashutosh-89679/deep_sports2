<?php
include 'database.php';


// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}

$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

$page = isset($_GET['page']) ? max(1, $_GET['page']) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$fetched_ladder_percent = null;
$fetched_kicker_percent = null;
$fetched_ei_percent = null;
$fetched_brokerage_percent = null;
$developer_name = null;
$location_name = null;
$developer_name = null;
$max_av = False;
$recent_closure = False;

if(isset($data['max_av']) && !empty($data['max_av'])){
    if(isset($data['max_av']) == "True"){
    $max_av = True;
    }
}
if(isset($data['recent_closure']) && !empty($data['recent_closure'])){
    $recent_closure = True;
}

//INNER JOIN
$sql = "SELECT
    bd.*,
    bc.name,
    bc.number,
    p.project_name,
    osr.status_id,
    osr.expected,
    osr.completed,
    bd.client_id
FROM
    booking_details bd
JOIN booked_clients bc ON
    bd.client_id = bc.User_id
JOIN project p ON
    bd.project_id = p.project_id
JOIN ob_status_records osr ON
    bd.os_status_id = osr.ob_record_id";

// Add conditional ordering
if ($max_av) {
    $sql .= " ORDER BY bd.agreement_value DESC";
} elseif ($recent_closure) {
    $sql .= " ORDER BY bd.closure_date DESC";
}

// Add LIMIT and OFFSET
$sql .= " LIMIT $limit OFFSET $offset";



$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}

$booking_records = array();


$countSql = "SELECT COUNT(*) AS total_count FROM booking_details";
$countResult = $conn->query($countSql);
if ($countResult) {
    $countRow = $countResult->fetch_assoc();
    $totalCount = $countRow['total_count'];
} else {
    die("Count query failed: " . $conn->error);
}

 $countResult = $conn->query($countSql);
    if ($countResult) {
        $countRow = $countResult->fetch_assoc();
        $totalCount = $countRow['total_count'];
    } else {
        die("Count query failed: " . $conn->error);
    }
    
    if ($page * $limit > $totalCount) {
    $limit = $totalCount % $limit;
}

$booking_records['total_count'] = ['count' => $totalCount];


//remove while loop and return the single row as an array in a variable
while ($row = $result->fetch_assoc()) {
    
    $generic_details = array(
        "booking_id" => $row["booking_id"],
        "client_id" => $row["client_id"],
        "project_id" => $row["project_id"],
        "wing" => $row["wing"],
        "flat_no" => $row["flat_no"],
        "configuration_id" => $row["configuration_id"],
        "carpet_area" => $row["carpet_area"],
        "closure_date" => $row["closure_date"],
        "closed_by" => $row["closed_by"],
        "sourced_by" => $row["sourced_by"],
        "cashback_amount" => $row["cashback_amount"],
        "agreement_value" => $row["agreement_value"],
        "csop" => $row["csop"],
        "name" => $row["name"],
        "number" => $row["number"],
        "project_name" => $row["project_name"]
    );

    $ob_status_details = array(
        "os_status_id" => $row["os_status_id"],
        "status_id" => $row["status_id"],
        "expected" => $row["expected"],
        "completed" => $row["completed"]
    );

    

    $project_id = $row["project_id"];
    $closure_date = $row["closure_date"];
    $booking_id = $row["booking_id"];


    $percentageSQL = "SELECT ladder_stage AS ladder_percent , base_brokerage , kicker_percent , ei_percent FROM booking_details WHERE booking_id = $booking_id";
    $resultPercentSQL = $conn->query($percentageSQL);
    if($resultPercentSQL){
        while($resultPercentrow = $resultPercentSQL->fetch_assoc()){
            $fetched_ladder_percent = $resultPercentrow["ladder_percent"];
            $fetched_kicker_percent = $resultPercentrow["kicker_percent"];
            $fetched_brokerage_percent = $resultPercentrow["base_brokerage"];
            $fetched_ei_percent = $resultPercentrow["ei_percent"];
        }
    }
    
    $followupSQL = "SELECT booking_id, MAX(followup_date) AS most_recent_followup_date, MAX(followup_for) AS followup_for FROM followups WHERE booking_id = '$booking_id' GROUP BY booking_id, followup_type LIMIT 1";
    $followupResult = $conn->query($followupSQL);
    if($followupResult){
        while ($resultFollowuprow = $followupResult->fetch_assoc()){
            $generic_details["recent_type"] = $resultFollowuprow["followup_for"];
            $generic_details["recent_date"] = $resultFollowuprow["most_recent_followup_date"];
        }
    }

   //FETCH THE LOCATION AND DEVELOPER_NAME 
    if ($project_id !== null) {
    
        $developer_sql = "SELECT c.company_name, d.developer_name, l.location_name FROM project AS p JOIN company AS c 
                          ON p.company_id = c.company_id JOIN developer AS d ON c.developer_id = d.developer_id 
                          JOIN location AS l ON d.location_id = l.location_id WHERE p.project_id = '$project_id'";
        $result_developer_name = $conn->query($developer_sql);
        if ($result_developer_name) {
            while ($result_row = $result_developer_name->fetch_assoc()) {
                $developer_name = $result_row['developer_name'];
                $company_name = $result_row['company_name'];
                $location_name = $result_row['location_name'];
                        }
                    }
                
    }



    // Create a booking record array
    $booking_record = array(
        'generic_details' => $generic_details,
        'ob_status_details' => $ob_status_details,
        'fetched_ladder_percent' => $fetched_ladder_percent,
        'fetched_kicker_percent' => $fetched_kicker_percent,
        'fetched_ei_percent' => $fetched_ei_percent,
        'fetched_brokerage_percent' => $fetched_brokerage_percent,
        'company_name' => $company_name,
        'developer_name' => $developer_name,
        'location_name' => $location_name,
    );


    // Add the booking record to the array of booking records
    $booking_records[] = $booking_record;
}



// Close the database connection
$conn->close();

// Return the array of booking records as JSON
header("Content-Type: application/json");
echo json_encode(array_values($booking_records));

?>
