<?php

include 'ladderDb.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}



// Initialize variables for headers
$locationId = null;
$developerId = null;
$projectId = null;

// Get the JSON data from the request body
$json_data = file_get_contents('php://input');

// Decode the JSON data into an associative array
$data = json_decode($json_data, true);
var_dump($data);

if (isset($data['location_id'])) {
    $location_id = $data['location_id'];
}

// Check if project_id header is set
if (isset($data['developer_name'])) {
    $developer_name = $data['developer_name'];
}



// Query to find the maximum project_id
$query = "SELECT MAX(developer_id) AS max_developer_id FROM developer";

// Execute the query
$result = $connection->query($query);

if ($result) {
    // Fetch the maximum project_id from the result
    $row = $result->fetch_assoc();
    $DeveloperId = $row['max_developer_id'] + 1;


        // Assuming you have already established a database connection
    
    // Your SQL INSERT query
    $insertQuery = "INSERT INTO developer ( developer_id, developer_name , location_id) VALUES ($DeveloperId, '$developer_name' , $location_id)";
    // Execute the query
    echo "SQL Query: " . $insertQuery . PHP_EOL;

    
   if ($connection->query($insertQuery) === TRUE) {
       
    $response = array(
        "status" => "success",
        "message" => "Project Added"
    );
    echo json_encode($response);
} else {
    $response = array(
        "status" => "error",
        "message" => $connection->error
    );
    echo json_encode($response);
}

 
} else {
    // Handle query error
    echo "Error executing the query: " . $connection->error;
}

// Close the database connection
$connection->close();
?>
