<?php
require_once('response.php');
require_once('db.php');

try {
    $conn = connectToDatabase();

    $page = isset($_GET['page']) ? max(1, $_GET['page']) : 1;
    $limit = 10;
    $offset = ($page - 1) * $limit;

    $json_data = file_get_contents('php://input');
    $data = json_decode($json_data, true);

    $daysFilter = isset($data['days']) ? $data['days'] : null;
    $projectFilter = isset($data['project_id']) ? $data['project_id'] : null;
    $developerFilter = isset($data['developer_id']) ? $data['developer_id'] : null;
    $branchFilter = isset($data['branch_id']) ? $data['branch_id'] : null;
    
    
    $companyFilter = isset($data['company_id']) ? $data['company_id'] : null;
    $submit_start_date = isset($data['submit_start_date']) ? $data['submit_start_date'] : null;
    $submit_end_date = isset($data['submit_end_date']) ? $data['submit_end_date'] : null;
    
    $data = [];
    $filterArrayData = [];

//Filter By Project
if($projectFilter !== null){
    $getByProject = "SELECT company_id FROM project WHERE project_id IN ($projectFilter)";
    $getByProjectResult = $conn->query($getByProject);

   if ($getByProjectResult) {
       while ($row = $getByProjectResult->fetch_assoc()) {
                $filterArrayData[] = $row['company_id'];
       }
       
   } else {
       echo json_encode(['error' => 'Query execution failed']);
     }
}

//Filter By Developer
if($developerFilter !== null){
    $getByDeveloper = "SELECT company_id FROM company WHERE developer_id IN ($developerFilter)";
    $getByDeveloperResult = $conn->query($getByDeveloper);

   if ($getByDeveloperResult) {
       while ($row = $getByDeveloperResult->fetch_assoc()) {
                $filterArrayData[] = $row['company_id'];
       }
       
   } else {
       echo json_encode(['error' => 'Query execution failed']);
     }
}

if($branchFilter !== null){
    $getByBranchFilter = "SELECT DISTINCT c.company_id
    FROM company c
    JOIN developer d ON c.developer_id = d.developer_id
    WHERE d.location_id IN ($branchFilter);";
    $getByBranchResult = $conn->query($getByBranchFilter);

   if ($getByBranchResult) {
       while ($row = $getByBranchResult->fetch_assoc()) {
                $filterArrayData[] = $row['company_id'];
       }
       
   } else {
       echo json_encode(['error' => 'Query execution failed']);
     }
}

if($companyFilter !== null){
    $getByCompanyFilter = "SELECT DISTINCT company_id
    FROM company 
    WHERE company_id IN ($companyFilter);";
    $getByCompanyResult = $conn->query($getByCompanyFilter);

   if ($getByCompanyResult) {
       while ($row = $getByCompanyResult->fetch_assoc()) {
                $filterArrayData[] = $row['company_id'];
       }
       
   } else {
       echo json_encode(['error' => 'Query execution failed']);
     }
}
    $filterArrayDataUnique = null;

    if ($filterArrayData !== null) {
        $filterArrayDataUnique = implode(',', array_unique($filterArrayData));
    }

    if ($page === 1) {
        // Query to get the count of records only on page 1
        $countSql = "SELECT COUNT(*) AS total_count FROM invoice AS i INNER JOIN company_estimation AS ce ON i.company_id = ce.company_id WHERE post_raise_id IN (2, 3)";

        if ($daysFilter !== null) {
            $countSql .= " AND DATEDIFF(CURDATE(), i.submit_date) = $daysFilter";
        }
    
        if (!empty($filterArrayDataUnique)) {
            $countSql .= " AND i.company_id IN ($filterArrayDataUnique)";
        }
    
    
        if ($submit_start_date !== null && $submit_end_date !== null) {
            $countSql .= " AND i.submit_date BETWEEN '$submit_start_date' AND '$submit_end_date'";
        }
        $countResult = $conn->query($countSql);

        if (!$countResult) {
            throw new Exception("Count query failed: " . $conn->error);
        }

        $countRow = $countResult->fetch_assoc();
        $totalCount = $countRow['total_count'];

        // Add total_count to the result only on page 1
        $data['total_count'] = ['count' => $totalCount];
    }

    $sql = "SELECT i.invoice_number, i.submit_date, i.invoice_receive_date, com.company_name, i.company_id, DATEDIFF(CURDATE(), i.submit_date) AS days_interval, i.submit_date + INTERVAL ce.commited_days DAY AS expected_date FROM invoice AS i INNER JOIN company_estimation AS ce ON i.company_id = ce.company_id INNER JOIN company AS com ON i.company_id = com.company_id WHERE post_raise_id IN (2, 3) AND submit_date IS NOT NULL";

    if ($daysFilter !== null) {
        $sql .= " AND DATEDIFF(CURDATE(), i.submit_date) = $daysFilter";
    }
    
    if (!empty($filterArrayDataUnique)) {
        $sql .= " AND i.company_id IN ($filterArrayDataUnique)";
    }
    
    
    if ($submit_start_date !== null && $submit_end_date !== null) {
        $sql .= " AND i.submit_date BETWEEN '$submit_start_date' AND '$submit_end_date'";
    }
    
    $sql .= " LIMIT $limit OFFSET $offset";

    $result = $conn->query($sql);

    if (!$result) {
        throw new Exception("Query failed: " . $conn->error);
    }

    while ($row = $result->fetch_assoc()) {
        $projectId = $row['company_id'];
        $projectNameQuery = "SELECT project_name FROM project WHERE company_id = '$projectId'";
        $projectNameResult = $conn->query($projectNameQuery);

        if (!$projectNameResult) {
            throw new Exception("Project name query failed: " . $conn->error);
        }

        $projectNameRow = $projectNameResult->fetch_assoc();

        $row['project_name'] = $projectNameRow['project_name'];
        $data[] = $row;
    }

    // Close the database connection
    $conn->close();

    // Ensure the result is always returned as an array
    $response = new Response();
    $response->setHttpStatusCode(200);
    $response->setSuccess(true);
    $response->addMessage("Data retrieved successfully");
    $response->setData(array_values($data));
    $response->send();

} catch (Exception $ex) {
    // Handle exceptions
    error_log("Error: " . $ex->getMessage(), 0);
    $response = new Response();
    $response->setHttpStatusCode(500);
    $response->setSuccess(false);
    $response->addMessage("An error occurred");
    $response->send();
} finally {
    // Close connection
    if (isset($conn)) {
        $conn->close();
    }
}
?>
