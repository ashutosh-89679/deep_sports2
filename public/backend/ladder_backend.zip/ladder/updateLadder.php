<?php
// Database configuration (update with your database credentials)
include 'ladderDb.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Initialize variables for headers
$locationId = null;
$developerId = null;

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}

// Check if developer_id header is set
$headers = getallheaders();

// Check if other headers are set
if (isset($headers['Http_start_date'])) {
    $ladderStartDate = $headers['Http_start_date'];
}

if (isset($headers['Http_end_date'])) {
    $ladderEndDate = $headers['Http_end_date'];
}

if (isset($headers['Http_ladder_type'])) {
    $ladderType = $headers['Http_ladder_type'];
}

// Check if other headers are set
if (isset($headers['Http_unique_id'])) {
    $uniqueId = $headers['Http_unique_id'];
}

// Check if other headers are set
if (isset($headers['Http_extended_date'])) {
    $extendedDate = $headers['Http_extended_date'];
}


// Check if other headers are set
if (isset($headers['Http_operation_type'])) {
    $operationType = $headers['Http_operation_type'];
    
} else {
    // If operation_type is not set in headers, return an error JSON response
    $response = ['error' => 'Operation type is missing'];
    header('Content-Type: application/json');
    echo json_encode($response);
    exit; // Exit the script
}

// Check if http_project_id header is required when operation_type is "single"
if ($operationType === 'single') {
    if (isset($headers['Http_project_id'])) {
        $singleProjectId = $headers['Http_project_id'];
    } else {
        // If http_project_id is missing when operation_type is "single", return an error JSON response
        $response = ['error' => 'Project ID is missing for single operation'];
        header('Content-Type: application/json');
        echo json_encode($response);
        exit; // Exit the script
    }
}

// Define the file path where you want to save the headers
$filePath = 'check2.txt';
$filePath2 = 'check.txt';

// Append the headers to the file
file_put_contents($filePath, json_encode($headers, JSON_PRETTY_PRINT) . PHP_EOL, FILE_APPEND);

try {
    // Connect to the database
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);

    // Set PDO to throw exceptions on errors
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if the http request method is POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Get the JSON data from the request body (remove json_encode)
        $json_data = file_get_contents("php://input");

        $data = json_decode($json_data, true);

        if ($operationType === 'multiple') {
            foreach ($data as $stageData) {
                // Process each stage's data
                // Access stage-specific data
                $stage = $stageData['stage'];
                $minValue = $stageData['min'];
                $maxValue = $stageData['max'];
                $percentValue = $stageData['percent'];

                // Create a new prepared statement for each stage
                $stmt = $pdo->prepare("UPDATE ladder 
                                       SET ladder_stage_start = :minValue, 
                                           ladder_stage_end = :maxValue, 
                                           stage_percent = :percentValue,
                                           ladder_extended_date = :ladder_extended_date,
                                           ladder_type = :ladder_type
                                       WHERE ladder_id = :ladder_id 
                                         AND ladder_stage = :stage
                                         AND ladder_start_date = :ladder_start_date
                                         AND ladder_end_date = :ladder_end_date");

                $stmt->bindParam(':minValue', $minValue);
                $stmt->bindParam(':maxValue', $maxValue);
                $stmt->bindParam(':percentValue', $percentValue);
                $stmt->bindParam(':ladder_id', $uniqueId);
                $stmt->bindParam(':stage', $stage);
                $stmt->bindParam(':ladder_start_date', $ladderStartDate);
                $stmt->bindParam(':ladder_end_date', $ladderEndDate);
                $stmt->bindParam(':ladder_type', $ladderType);
                $stmt->bindParam(':ladder_extended_date', $extendedDate);


                if ($stmt->execute()) {
                    // Data updated successfully
                } else {
                    // Log the SQL error if the update fails
                    $error = "SQL Error: " . implode(", ", $stmt->errorInfo()) . "\n";
                    file_put_contents($filePath2, $error, FILE_APPEND);
                }
            }

            // Return a JSON response for success
            $response = ['message' => 'Data received and updated successfully'];
            header('Content-Type: application/json');
            echo json_encode($response);
        } elseif ($operationType === 'single') {
            if (isset($headers['Http_project_id'])) {
                $singleProjectId = $headers['Http_project_id'];
                $single_unique_id = $headers['Http_single_unique_id'];
                $stmtDelProject = $pdo->prepare("DELETE FROM project_ladder WHERE project_id =  :project_id AND ladder_id = :ladder_id");
                $stmtDelProject->bindParam(':project_id', $singleProjectId);
                $stmtDelProject->bindParam(':ladder_id', $single_unique_id);
                $stmtDelProject->execute();
            } else {
                // If http_project_id is missing when operation_type is "single", return an error JSON response
                $response = ['error' => 'Project ID is missing for single operation'];
                header('Content-Type: application/json');
                echo json_encode($response);
                exit; // Exit the script
            }

            // Generate a unique ladder ID
            $uniqueId = generateUniqueLadderId();

    // Insert data into the ladder table
    $stmt = $pdo->prepare("INSERT INTO ladder (ladder_id, ladder_start_date, ladder_end_date, ladder_type, ladder_extended_date ,ladder_stage, ladder_stage_start, ladder_stage_end, stage_percent) 
                           VALUES (:ladder_id, :ladder_start_date, :ladder_end_date, :ladder_type , :ladder_extended_date , :stage, :minValue, :maxValue, :percentValue)");

    // Insert data into the project_ladder table

    foreach ($data as $stageData) {
        // Process each stage's data
        $stage = $stageData['stage'];
        $minValue = $stageData['min'];
        $maxValue = $stageData['max'];
        $percentValue = $stageData['percent'];

        $stmt->bindParam(':ladder_id', $uniqueId);
        $stmt->bindParam(':ladder_start_date', $ladderStartDate);
        $stmt->bindParam(':ladder_end_date', $ladderEndDate);
        $stmt->bindParam(':ladder_extended_date' , $extendedDate);
        $stmt->bindParam(':ladder_type', $ladderType);
        $stmt->bindParam(':stage', $stage);
        $stmt->bindParam(':minValue', $minValue);
        $stmt->bindParam(':maxValue', $maxValue);
        $stmt->bindParam(':percentValue', $percentValue);

        if ($stmt->execute()) {
            
        } else {
            // Log the SQL error if the ladder insert fails
            $error = "SQL Error (ladder): " . implode(", ", $stmt->errorInfo()) . "\n";
            file_put_contents($filePath2, $error, FILE_APPEND);
        }
    }

        // Return a JSON response for success
        $response = ['message' => 'Data received and inserted successfully' , 'uniqueId' => $uniqueId];
        header('Content-Type: application/json');
        echo json_encode($response);
        // Data inserted into the ladder table successfully
        $stmtProject = $pdo->prepare("INSERT INTO project_ladder (project_id, ladder_id) VALUES (:project_id, :ladder_id)");
        $stmtProject->bindParam(':project_id', $singleProjectId);
        $stmtProject->bindParam(':ladder_id', $uniqueId);
        $stmtProject->execute();

        } else {
            // Return a JSON response for invalid operation type
            $response = ['error' => 'Invalid operation type'];
            header('Content-Type: application/json');
            echo json_encode($response);
        }
    } else {
        // Return a JSON response for invalid request method
        $response = ['error' => 'Invalid request method'];
        header('Content-Type: application/json');
        echo json_encode($response);
    }
} catch (PDOException $e) {
    // Return a JSON response for database errors
    $response = ['error' => 'Database error: ' . $e->getMessage()];
    header('Content-Type: application/json');
    echo json_encode($response);
}

function generateUniqueLadderId() {
    $uniqueId = 'ladder_' . time();
    return $uniqueId;
}

?>
