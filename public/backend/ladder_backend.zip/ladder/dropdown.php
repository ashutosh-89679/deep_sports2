<?php
// Database connection details
include 'ladderDb.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");


if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}


// Check the connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

$data = array();

$locationQuery = "SELECT DISTINCT location_id , location_name FROM location";
$locationResult = $connection->query($locationQuery);

while ($locationRow = $locationResult->fetch_assoc()) {
    $locationId = $locationRow['location_id'];
    $location_name = $locationRow['location_name'];

    $location = array(
        'location_id' => $locationId,
        'location_name' => $location_name,
        'developers' => array()
    );

    $developerQuery = "SELECT DISTINCT developer_id , developer_name FROM developer WHERE location_id = $locationId";
    $developerResult = $connection->query($developerQuery);

    while ($developerRow = $developerResult->fetch_assoc()) {
        $developerId = $developerRow['developer_id'];
        $developer_name = $developerRow['developer_name'];

        $developer = array(
            'developer_id' => $developerId,
            'developer_name' => $developer_name,
            'companies' => array()
        );

        $companyQuery = "SELECT DISTINCT company_id , company_name FROM company WHERE developer_id = $developerId";
        $companyResult = $connection->query($companyQuery);

        while ($companyRow = $companyResult->fetch_assoc()) {
            $companyId = $companyRow['company_id'];
            $company_name = $companyRow['company_name'];

            $company = array(
                'company_id' => $companyId,
                'company_name' => $company_name,
                'projects' => array()
            );

            $projectQuery = "SELECT DISTINCT project_id , project_name FROM project WHERE company_id = $companyId";
            $projectResult = $connection->query($projectQuery);

            while ($projectRow = $projectResult->fetch_assoc()) {
                $projectId = $projectRow['project_id'];
                $project_name = $projectRow['project_name'];

                $project = array(
                    'project_id' => $projectId,
                    'project_name' => $project_name
                );

                $company['projects'][] = $project;
            }

            $developer['companies'][] = $company;
        }

        $location['developers'][] = $developer;
    }

    $data[] = $location;
}

// Convert the data to JSON
$jsonData = json_encode($data, JSON_PRETTY_PRINT);

// Output the JSON data
echo $jsonData;

// Close the database connection
$connection->close();
?>
