<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'database.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400'); // cache for 1 day
}

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD'])) {
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    }
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS'])) {
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    }
    exit();
}

// Function to handle JSON response
function jsonResponse($statusCode, $data) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
}

// Get the JSON data from the request body
$json_data = file_get_contents('php://input');

// Decode the JSON data into an associative array
$data = json_decode($json_data, true);

// Check if project_id key exists
if (isset($data['project_id'])) {
    $project_id = $data['project_id'];
}

// Check if client_id key exists
if (isset($data['client_id'])) {
    $client_id = $data['client_id'];
}

// Check other keys in a similar manner
if (isset($data['booking_id'])) {
    $booking_id = $data['booking_id'];
}

if (isset($data['wing'])) {
    $wing = $data['wing'];
}

if (isset($data['flat_no'])) {
    $flat_no = $data['flat_no'];
}

if (isset($data['typology'])) {
    $typology = $data['typology'];
}

if (isset($data['carpet_area'])) {
    $carpet_area = $data['carpet_area'];
}

if (isset($data['closure_date'])) {
    $closure_date = $data['closure_date'];
}

if (isset($data['closed_by'])) {
    $closed_by = $data['closed_by'];
}

if (isset($data['agreement_value'])) {
    $agreement_value = $data['agreement_value'];
}

if (isset($data['os_status_id'])) {
    $os_status_id = $data['os_status_id'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Establish a database connection

    // Define the SQL query for inserting data with placeholders
    $sql = "INSERT INTO `booking_details` (`booking_id`, `client_id`, `project_id`, `typology`, `carpet_area`, `closure_date`, `closed_by`, `agreement_value`, `os_status_id`)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare the SQL statement
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Error: " . $conn->error); // Check for errors in prepare
    }

    // Bind the parameters
    $stmt->bind_param(
        'iiisdsisi',
        $booking_id,
        $client_id,
        $project_id,
        $typology,
        $carpet_area,
        $closure_date,
        $closed_by,
        $agreement_value,
        $os_status_id
    );

    // Execute the statement
    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();
        jsonResponse(200, ['message' => 'Data inserted successfully.']);
    } else {
        // Capture and display the SQL error
        $error = [
            'error' => 'Data insertion failed',
            'sql_error' => $stmt->error, // Get the SQL error message
        ];
        $stmt->close();
        $conn->close();
        jsonResponse(500, $error);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'PATCH') {

    $setClauses = [];
    $sql = "UPDATE `booking_details` SET ";
    
    $param_booking_id = null;

    
    if (!is_null($wing)) {
        $setClauses[] = "`wing` = ?";
        $param_wing = $wing;
    }

    if (!is_null($flat_no)) {
        $setClauses[] = "`flat_no` = ?";
        $param_flat_no = $flat_no;
    }
    
    if (!is_null($typology)) {
        $setClauses[] = "`configuration_id` = ?";
        $param_typology = $typology;
    }
    
    if (!is_null($carpet_area)) {
        $setClauses[] = "`carpet_area` = ?";
        $param_carpet_area = $carpet_area;
    }
    
    
    if (!is_null($closed_by)) {
        $setClauses[] = "`closed_by` = ?";
        $param_closed_by = $closed_by;
    }
    
    if (!is_null($agreement_value)) {
        $setClauses[] = "`agreement_value` = ?";
        $param_agreement_value = $agreement_value;
    }
    

    $sql .= implode(", ", $setClauses);
    $sql .= " WHERE `client_id` = ?";
    
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Error: " . $conn->error);
    }

    // Adjust paramTypes based on the number of parameters
    $paramTypes = str_repeat('s', count($setClauses)) . 'i';
    $bindParams = [$param_wing, $param_flat_no, $param_typology, $param_carpet_area, $param_closed_by, $param_agreement_value, $client_id];

    $stmt->bind_param($paramTypes, ...$bindParams);

    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();
        jsonResponse(200, ['message' => 'Data updated successfully.']);
    } else {
        $error = [
            'error' => 'Data update failed',
            'sql_error' => $stmt->error, 
        ];
        $stmt->close();
        $conn->close();
        jsonResponse(500, $error);
    }
}