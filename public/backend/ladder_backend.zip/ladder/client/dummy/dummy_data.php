<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}


// List of companies
$companies = [
    "Dosti_company", "Raunak Group Company", "Puranics grand central",
    "Mahindra Happinest", "Godrej Partner Connect", "Raymond REALTY",
    "RUNWAL Group", "Prestige Group"
];

// Seed for random number generator (use any integer value)
$seed = 12345;
mt_srand($seed);

// Array to store restructured data
$restructured_data = [];

foreach ($companies as $company_id => $company_name) {
    // Initialize data for the current company
    $company_data = ["company_id" => $company_id + 1, "company_name" => $company_name];
    
    // Iterate through each month
    for ($month = 1; $month <= 12; $month++) {
        // Initialize array to store actual amounts for each day range in the month
        $month_data = [];

        // Iterate through each day range in the month (1-10, 11-20, 21-30)
        for ($day_range = 1; $day_range <= 3; $day_range++) {
            // Insert 0 for some places, otherwise generate a stable random actual amount between 100,000 and 600,000
            $actual_amount = ($day_range == 2 && $month % 2 == 0) ? 0 : mt_rand(100000, 600000);

            // Add the actual amount to the month data
            $month_data[] = $actual_amount;
        }

        // Add the month data to the company data using the month name as the key
        $company_data[date('F', mktime(0, 0, 0, $month, 1))] = $month_data;
    }

    // Add the company data to the restructured data array
    $restructured_data[] = $company_data;
}

// Print the generated data in JSON format
echo json_encode($restructured_data, JSON_PRETTY_PRINT);

?>
