<?php
$host = "localhost";
$username = "aarnainw_ashutosh";
$password = "4PtX8dn]&m!-";
$database = "aarnainw_finance_main";


// Create a new MySQLi connection
$connection = new mysqli($host, $username, $password, $database);

// Check for a connection error
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}
?>