<?php
include 'ladderDb.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);



header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}


$json_data = file_get_contents('php://input');


$data = json_decode($json_data, true);


if (isset($data['project_id'])) {
    $projectIds = explode(',', $data['project_id']);
}
if (isset($data['start_date'])) {
    $KickerStartDate = $data['start_date'];
}

if (isset($data['end_date'])) {
    $KickerEndDate = $data['end_date'];
}

if (isset($data['target_amount'])) {
    $KickerTargetAmount = $data['target_amount'];
}

if (isset($data['target_unit'])) {
    $KickerTargetUnit = $data['target_unit'];
}

if (isset($data['kicker_condition'])) {
    $KickerCondition = $data['kicker_condition'];
}

if (isset($data['target_percent'])) {
    $KickerTargetPercent = $data['target_percent'];
}

if (isset($data['kicker_value'])) {
    $KickerValue = $data['kicker_value'];
}

if (isset($data['unique_id'])) {
    $uniqueId = $data['unique_id'];
}

if (isset($data['extended_date'])) {
    $KickerExtendedDate = $data['extended_date'];
}



// Convert the headers to a JSON string
$headersJson = json_encode($data, JSON_PRETTY_PRINT);

// Define the file path where you want to save the headers
$filePath = 'check.txt';

// Append the headers to the file
file_put_contents($filePath, $headersJson . PHP_EOL, FILE_APPEND);


try {
    // Connect to the database
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if the HTTP request method is POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                $stmt = $pdo->prepare("UPDATE kicker
                SET
                Kicker_target_in_amount = :Kicker_target_in_amount,
                Kicker_target_in_unit = :Kicker_target_in_unit,
                kicker_condition = :kicker_condition,
                kicker_in_percent = :kicker_in_percent,
                kicker_in_value = :kicker_in_value,
                kicker_extended_date = :kicker_extended_date
                WHERE
                kicker_start_date = :kicker_start_date
                    AND kicker_end_date = :kicker_end_date
                    AND kicker_unique_id = :kicker_unique_id");
                $stmt->bindParam(':Kicker_target_in_amount', $KickerTargetAmount);
                $stmt->bindParam(':Kicker_target_in_unit', $KickerTargetUnit);
                $stmt->bindParam(':kicker_condition', $KickerCondition);
                $stmt->bindParam(':kicker_in_percent', $KickerTargetPercent);
                $stmt->bindParam(':kicker_in_value', $KickerValue);
                $stmt->bindParam(':kicker_start_date', $KickerStartDate);
                $stmt->bindParam(':kicker_end_date', $KickerEndDate);
                $stmt->bindParam(':kicker_extended_date', $KickerExtendedDate);
                $stmt->bindParam(':kicker_unique_id', $uniqueId);
                $stmt->execute();

            // Return a JSON response for success
            $response = ['message' => 'Data received and Updated successfully'];
            header('HTTP/1.1 200 OK');
            header('Content-Type: application/json');
            echo json_encode($response);
        
    } else {
        $response = ['error' => 'Invalid request method'];
        header('HTTP/1.1 405 Method Not Allowed');
        header('Content-Type: application/json');
        echo json_encode($response);
    }
} catch (PDOException $e) {
    $response = ['error' => 'Database error: ' . $e->getMessage()];
    header('HTTP/1.1 500 Internal Server Error');
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
