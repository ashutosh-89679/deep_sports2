<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'database.php';


function connectToDatabase()
{
    global $dbHost, $dbUsername, $dbPassword, $dbName;
    $conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}


$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

function jsonResponse($statusCode, $data)
{
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
}

$company_id = null;
$submit_date = null;

if (isset($data['company_id'])) {
    $company_id = $data['company_id'];
}

if (isset($data['submit_date'])) {
    $submit_date = $data['submit_date'];
}

if (!empty($company_id) && !empty($submit_date)) {
    $conn = connectToDatabase();
    
    $sql = "SELECT
                `company_id`,
                `commited_days`,
                DATE_ADD(?, INTERVAL `commited_days` DAY) AS expected_date
            FROM
                company_estimation WHERE `company_id` = ?";
    
    $stmt = $conn->prepare($sql);

    $stmt->bind_param('ss', $submit_date, $company_id);

    if ($stmt->execute()) {
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $expected_date = $row['expected_date'];

        jsonResponse(200, ['expected_date' => $expected_date]);
    } else {
        jsonResponse(500, ['error' => 'Failed to execute the query']);
    }
} else {
    jsonResponse(400, ['error' => 'Company_id or Submit Date is empty']);
}

?>
