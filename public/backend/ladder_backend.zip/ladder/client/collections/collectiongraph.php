<?php

$servername = "localhost";
$username = "aarnainw_ashutosh";
$password = "4PtX8dn]&m!-";
$database = "aarnainw_finance_main";

$conn = new mysqli($servername, $username, $password, $database);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get JSON data from the request body
$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

// Initialize variables for date and company_id filtration
$start_date = null;
$end_date = null;
$company_id = null;

$daysFilter = isset($data['days']) ? $data['days'] : null;
$projectFilter = isset($data['project_id']) ? $data['project_id'] : null;
$developerFilter = isset($data['developer_id']) ? $data['developer_id'] : null;
$branchFilter = isset($data['branch_id']) ? $data['branch_id'] : null;
$companyFilter = isset($data['company_id']) ? $data['company_id'] : null;

$filterArrayData = [];

// Check if start_date, end_date, and company_id are set in the input data
if (isset($data['start_date'])) {
    $start_date = $data['start_date'];
}

if (isset($data['end_date'])) {
    $end_date = $data['end_date'];
}

//Filter By Project
if ($projectFilter !== null && !empty($projectFilter)) {
    $getByProject = "SELECT company_id FROM project WHERE project_id IN ($projectFilter)";
    $getByProjectResult = $conn->query($getByProject);

   if ($getByProjectResult) {
       while ($row = $getByProjectResult->fetch_assoc()) {
                $filterArrayData[] = $row['company_id'];
       }
       
   } else {
       echo json_encode(['error' => 'Query execution failed']);
     }
}

//union

//Filter By Developer
if($developerFilter !== null){
    $getByDeveloper = "SELECT company_id FROM company WHERE developer_id IN ($developerFilter)";
    $getByDeveloperResult = $conn->query($getByDeveloper);

   if ($getByDeveloperResult) {
       while ($row = $getByDeveloperResult->fetch_assoc()) {
                $filterArrayData[] = $row['company_id'];
       }
       
   } else {
       echo json_encode(['error' => 'Query execution failed']);
     }
}

if($branchFilter !== null){
    $getByBranchFilter = "SELECT DISTINCT c.company_id
    FROM company c
    JOIN developer d ON c.developer_id = d.developer_id
    WHERE d.location_id IN ($branchFilter);";
    $getByBranchResult = $conn->query($getByBranchFilter);

   if ($getByBranchResult) {
       while ($row = $getByBranchResult->fetch_assoc()) {
                $filterArrayData[] = $row['company_id'];
       }
       
   } else {
       echo json_encode(['error' => 'Query execution failed']);
     }
}

if($companyFilter !== null){
    $getByCompanyFilter = "SELECT DISTINCT company_id
    FROM company 
    WHERE company_id IN ($companyFilter);";
    $getByCompanyResult = $conn->query($getByCompanyFilter);

   if ($getByCompanyResult) {
       while ($row = $getByCompanyResult->fetch_assoc()) {
                $filterArrayData[] = $row['company_id'];
       }
       
   } else {
       echo json_encode(['error' => 'Query execution failed']);
     }
}

$filterArrayDataUnique = null;

if ($filterArrayData !== null){
    $filterArrayDataUnique = implode(',', array_unique($filterArrayData));
}

// SQL query with date and company_id filtration
$sql = "
        SELECT
        COUNT(
            CASE
                WHEN i.invoice_raise_date IS NOT NULL AND i.submit_date IS NULL THEN 'not_submitted'
                ELSE 0
            END
        ) AS not_submitted,
        COUNT(
            CASE
                WHEN i.invoice_raise_date = i.submit_date THEN 'on_time'
                ELSE 0
            END
        ) AS on_time,
        COUNT(
            CASE
                WHEN i.invoice_raise_date IS NULL THEN 'not_raise'
                ELSE 0
            END
           ) AS not_raised,
         COUNT(
            CASE
                WHEN i.invoice_raise_date != i.submit_date  THEN 'not_raise'
                ELSE 0
            END
           ) AS delayed_submitted,
         COUNT(
            CASE
                WHEN i.invoice_raise_date != i.submit_date  THEN 'not_raise'
                ELSE 0
            END
           ) AS delayed_raised
        FROM
        booking_details bd
        LEFT JOIN invoice i ON bd.client_id = i.client_id
        LEFT JOIN ob_status_records osr ON bd.booking_id = osr.booking_id
        WHERE
        osr.status_id = 3 AND osr.completed IS NOT NULL";

// Add date filtration if both start_date and end_date are provided
if ($start_date !== null && $end_date !== null) {
    $sql .= " AND osr.completed BETWEEN '$start_date' AND '$end_date'";
}


// Add company_id filtration if provided
if (!empty($filterArrayDataUnique)) {
    $sql .= " AND i.company_id IN ($filterArrayDataUnique)";
}



$sql .= ";";

$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}

$data = [];

while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

// Close connection
$conn->close();

// Return data as JSON
echo json_encode($data);

?>
