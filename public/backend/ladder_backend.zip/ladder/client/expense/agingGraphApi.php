<?php

$servername = "localhost";
$username = "aarnainw_ashutosh";
$password = "4PtX8dn]&m!-";
$database = "aarnainw_finance_main";
// Create connection
$conn = new mysqli($servername, $username, $password, $database);


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Build the SQL query for ascending order
$sqlAscending = "
    SELECT
        ce.company_id,
        ce.avg_receive_days,
        c.company_name
    FROM
        company_estimation ce
        JOIN company c ON ce.company_id = c.company_id
    ORDER BY
        ce.avg_receive_days ASC, c.company_name ASC
";

// Execute the query for ascending order
$resultAscending = $conn->query($sqlAscending);

if (!$resultAscending) {
    die("Query for ascending order failed: " . $conn->error);
}

// Fetch the data into an array for ascending order
$dataAscending = [];
while ($row = $resultAscending->fetch_assoc()) {
    $dataAscending[] = $row;
}

// Build the SQL query for descending order
$sqlDescending = "
    SELECT
        ce.company_id,
        ce.avg_receive_days,
        c.company_name
    FROM
        company_estimation ce
        JOIN company c ON ce.company_id = c.company_id
    ORDER BY
        ce.avg_receive_days DESC, c.company_name DESC
";

// Execute the query for descending order
$resultDescending = $conn->query($sqlDescending);

if (!$resultDescending) {
    die("Query for descending order failed: " . $conn->error);
}

// Fetch the data into an array for descending order
$dataDescending = [];
while ($row = $resultDescending->fetch_assoc()) {
    $dataDescending[] = $row;
}

// Close the connection
$conn->close();

// Return the data as JSON
echo json_encode(['ascending' => $dataAscending, 'descending' => $dataDescending]);

?>
