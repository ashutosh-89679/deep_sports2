<?php
include 'ladderDb.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}


$json_data = file_get_contents('php://input');


$data = json_decode($json_data , true);

// Check if project_id header is set
if (isset($data['project_id'])) {
    $projectId = $data['project_id'];
}

// Check if other headers are set
if (isset($data['start_date'])) {
    $EiStartDate = $data['start_date'];
}

if (isset($data['end_date'])) {
    $EiEndDate = $data['end_date'];
}

if (isset($data['target_amount'])) {
    $EiTargetAmount = $data['target_amount'];
}

if (isset($data['target_unit'])) {
    $EiTargetUnit = $data['target_unit'];
}

if (isset($data['ei_condition'])) {
    $Eicondition = $data['ei_condition'];
}

if (isset($data['target_percent'])) {
    $EiTargetPercent = $data['target_percent'];
}

if (isset($data['ei_value'])) {
    $Eivalue = $data['ei_value'];
}

if (isset($data['unique_id'])) {
    $uniqueId = $data['unique_id'];
}

if (isset($data['extended_date'])) {
    $extendedDate = $data['extended_date'];
}

// Convert the headers to a JSON string
$headersJson = json_encode($data, JSON_PRETTY_PRINT);

// Define the file path where you want to save the headers
$filePath = 'newcheck.txt';

// Append the headers to the file
file_put_contents($filePath, $headersJson . PHP_EOL, FILE_APPEND);


try {
    // Connect to the database
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if the HTTP request method is POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                $stmt = $pdo->prepare("UPDATE ei
                SET
                    ei_target_amount = :ei_target_amount,
                    ei_target_unit = :ei_target_unit,
                    ei_conditon = :ei_condition,
                    ei_percent = :ei_percent,
                    ei_value = :ei_value,
                    ei_extended_date = :ei_extended_date
                WHERE
                    ei_tenure_start_date = :ei_tenure_start_date
                    AND ei_tenure_end_date = :ei_tenure_end_date
                    AND ei_unique_id = :ei_unique_id");
                $stmt->bindParam(':ei_target_amount', $EiTargetAmount);
                $stmt->bindParam(':ei_target_unit', $EiTargetUnit);
                $stmt->bindParam(':ei_condition', $Eicondition);
                $stmt->bindParam(':ei_percent', $EiTargetPercent);
                $stmt->bindParam(':ei_value', $Eivalue);
                $stmt->bindParam(':ei_tenure_start_date', $EiStartDate);
                $stmt->bindParam(':ei_tenure_end_date', $EiEndDate);
                $stmt->bindParam(':ei_extended_date', $extendedDate);
                $stmt->bindParam(':ei_unique_id', $uniqueId);
                $stmt->execute();

            // Return a JSON response for success
            $response = ['message' => 'Data received and Updated successfully'];
            header('HTTP/1.1 200 OK');
            header('Content-Type: application/json');
            echo json_encode($response);
        
    } else {
        $response = ['error' => 'Invalid request method'];
        header('HTTP/1.1 405 Method Not Allowed');
        header('Content-Type: application/json');
        echo json_encode($response);
    }
} catch (PDOException $e) {
    $response = ['error' => 'Database error: ' . $e->getMessage()];
    header('HTTP/1.1 500 Internal Server Error');
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
