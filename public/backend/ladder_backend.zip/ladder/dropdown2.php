<?php
// Database connection details
$dbHost = 'localhost';
$dbUsername = "aarnainw_ashutosh";
$dbPassword = "4PtX8dn]&m!-";
$dbName = "aarnainw_finance_main";


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");


if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}

// Create a database connection
$conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$data = array();

$independentDevelopers = array();

// Fetch developers with location_id as null
$independentDeveloperQuery = "SELECT DISTINCT developer_id, developer_name FROM developer WHERE location_id IS NULL";
$independentDeveloperResult = $conn->query($independentDeveloperQuery);

while ($independentDeveloperRow = $independentDeveloperResult->fetch_assoc()) {
    $developerId = $independentDeveloperRow['developer_id'];
    $developer = array(
        'developer_id' => $developerId,
        'developer_name' => $independentDeveloperRow['developer_name'],
        'companies' => array()
    );
    
    $companyQuery = "SELECT DISTINCT company_id , company_name FROM company WHERE developer_id = $developerId";
    $companyResult = $conn->query($companyQuery);
    
    while ($companyRow = $companyResult->fetch_assoc()) {
        $companyId = $companyRow['company_id'];
        $company_name = $companyRow['company_name'];

        $company = array(
            'company_id' => $companyId,
            'company_name' => $company_name,
            'projects' => array()
        );

        $projectQuery = "SELECT DISTINCT project_id , project_name FROM project WHERE company_id = $companyId";
        $projectResult = $conn->query($projectQuery);

        while ($projectRow = $projectResult->fetch_assoc()) {
            $projectId = $projectRow['project_id'];
            $project_name = $projectRow['project_name'];

            $project = array(
                'project_id' => $projectId,
                'project_name' => $project_name
            );

            $company['projects'][] = $project;
        }

        $developer['companies'][] = $company;
    }
    
    $independentDevelopers[] = $developer;
}

$locationQuery = "SELECT DISTINCT location_id , location_name FROM location";
$locationResult = $conn->query($locationQuery);


while ($locationRow = $locationResult->fetch_assoc()) {
    $locationId = $locationRow['location_id'];
    $location_name = $locationRow['location_name'];

    $location = array(
        'location_id' => $locationId,
        'location_name' => $location_name,
        'developers' => array()
        );
    

    $developerQuery = "SELECT DISTINCT developer_id , developer_name FROM developer WHERE location_id = $locationId";
    $developerResult = $conn->query($developerQuery);

    if ($developerResult->num_rows > 0) {
        while ($developerRow = $developerResult->fetch_assoc()) {
        $developerId = $developerRow['developer_id'];
        $developer_name = $developerRow['developer_name'];

        $developer = array(
            'developer_id' => $developerId,
            'developer_name' => $developer_name,
            'companies' => array()
        );

        $companyQuery = "SELECT DISTINCT company_id , company_name FROM company WHERE developer_id = $developerId";
        $companyResult = $conn->query($companyQuery);

        while ($companyRow = $companyResult->fetch_assoc()) {
            $companyId = $companyRow['company_id'];
            $company_name = $companyRow['company_name'];

            $company = array(
                'company_id' => $companyId,
                'company_name' => $company_name,
                'projects' => array()
            );

            $projectQuery = "SELECT DISTINCT project_id , project_name FROM project WHERE company_id = $companyId";
            $projectResult = $conn->query($projectQuery);

            while ($projectRow = $projectResult->fetch_assoc()) {
                $projectId = $projectRow['project_id'];
                $project_name = $projectRow['project_name'];

                $project = array(
                    'project_id' => $projectId,
                    'project_name' => $project_name
                );

                $company['projects'][] = $project;
            }

            $developer['companies'][] = $company;
        }

        $location['developers'][] = $developer;
    }
    } else {
        $localityQuery = "SELECT DISTINCT locality_id, locality_name FROM locality WHERE location_id = $locationId";
        $localityResult = $conn->query($localityQuery);

        while ($localityRow = $localityResult->fetch_assoc()) {
            $localityId = $localityRow['locality_id'];
            $locality_name = $localityRow['locality_name'];

            $locality = array(
                'locality_id' => $localityId,
                'locality_name' => $locality_name,
                'projects' => array()
            );

            $projectQuery = "SELECT DISTINCT project_id , project_name FROM project WHERE locality_id = $localityId";
            $projectResult = $conn->query($projectQuery);

            while ($projectRow = $projectResult->fetch_assoc()) {
                $projectId = $projectRow['project_id'];
                $project_name = $projectRow['project_name'];

                $project = array(
                    'project_id' => $projectId,
                    'project_name' => $project_name
                );

                $locality['projects'][] = $project;
                $locality['independent_developers'] = $independentDevelopers;
            }

            $location['localities'][] = $locality;
        }
    }

    $data[] = $location;    
}


// Convert the data to JSON
$jsonData = json_encode($data, JSON_PRETTY_PRINT);

// Output the JSON data
echo $jsonData;

// Close the database connection
$conn->close();
?>
