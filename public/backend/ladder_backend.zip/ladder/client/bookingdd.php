<?php
include 'database.php';

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}


// Define SQL queries for each table
$tableQueries = [
    "project" => "SELECT project_id AS id, project_name AS name FROM project",
    "developer" => "SELECT developer_id AS id, developer_name AS name FROM developer",
    "location" => "SELECT location_id AS id , location_name AS name FROM location",
    "company" => "SELECT company_id AS id , company_name AS name FROM company",
    "locality" => "SELECT locality_id as id , locality_name as name FROM locality",
    "configuration" => "SELECT configuration_id AS id, configuration_name AS name FROM configuration",
    "invoice_post_raise_status" => "SELECT status_id AS id, status_name AS name FROM invoice_post_raise_status",
    "ob_table" => "SELECT OB_status  AS id, ob_show_name AS name FROM ob_table",
    "source_by_and_closed_by" => "SELECT sales_user_id AS id, user_name AS name FROM sales_emp"
];


// Execute queries and store results in an associative array
$data = [];

foreach ($tableQueries as $tableName => $query) {
    $result = $conn->query($query);

    if ($result) {
        $tableData = [];

        while ($row = $result->fetch_assoc()) {
            $tableData[] = $row;
        }

        $data[$tableName] = $tableData;
    } else {
        // Handle query errors
        $data[$tableName] = "Error: " . $conn->error;
    }
}

// Return the data as JSON
header('Content-Type: application/json');
echo json_encode($data);

// Close the database connection
$conn->close();
?>
