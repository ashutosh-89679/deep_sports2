<?php

include 'database.php';


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}





$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

$booking_id = null;

// FETCH
if ($_SERVER['REQUEST_METHOD'] === 'PATCH') {
    if (isset($data['booking_id'])) {
        $booking_id = $data['booking_id'];
    }
    
$sql = "SELECT followup_date, followup_type, followup_for, followup_comment FROM `followups` WHERE booking_id IN ($booking_id) ORDER BY `followup_date` DESC ;";
    $result = $conn->query($sql);

    if ($result) {
        $followupDataArray = array();

        while ($row = $result->fetch_assoc()) {
            $followupData = array(
                'followup_date' => $row['followup_date'],
                'followup_type' => $row['followup_type'],
                'followup_comment' => $row['followup_comment'],
                'followup_for' => $row['followup_for']
            );

            $followupDataArray[] = $followupData; 
        }

        echo json_encode($followupDataArray);
    } else {
        echo json_encode(['error' => 'Query execution failed']);
    }
}

// PUT
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $followup_type = null;
    $followup_date = null;
    $followup_comment = null;

    if (isset($data['followup_type'])){
        $followup_type = $data['followup_type'];
    }

    if (isset($data['followup_date'])){
        $followup_date = $data['followup_date'];
    }
    
    if (isset($data['followup_for'])){
        $followup_for = $data['followup_for'];
    }

    if (isset($data['followup_comment'])){
        $followup_comment = $data['followup_comment'];
    }
    

    if ($followup_date !== null && $followup_type !== null && $followup_comment !== null) {
        if(isset($data['booking_id'])){
            $booking_id = $data['booking_id'];
        }

        $param_booking_id = intval($booking_id); 
    
        $sql = "INSERT INTO `followups` (followup_date, followup_type, followup_for, followup_comment, booking_id) VALUES ('$followup_date', '$followup_type', $followup_for, '$followup_comment', $param_booking_id)";
    
        if ($conn->query($sql) === TRUE) {
            $response = array("message" => "Follow-up added successfully");
            echo json_encode($response);
        } else {
            $response = array("message" => "Failed to add follow-up: " . $conn->error);
            echo json_encode($response);
        }
    }
    
    
    else {
        $response = array("message" => "Incomplete data for follow-up");
        echo json_encode($response);
    }
}



?>
