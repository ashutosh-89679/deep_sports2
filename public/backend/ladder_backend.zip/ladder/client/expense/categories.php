<?php
$servername = "localhost";
$username = "aarnainw_ashutosh";
$password = "4PtX8dn]&m!-";
$database = "aarnainw_finance_main";

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}

$conn = new mysqli($servername, $username, $password, $database);


function jsonResponse($statusCode, $data)
{
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
}

$json_data = file_get_contents('php://input');

$data = json_decode($json_data, true);


$type = isset($data['type']) ? $data['type'] : null;
$category_id = isset($data['category_id']) ? $data['category_id'] : null;
$name = isset($data['name']) ? $data['name'] : null;


//FOR INSERTING 
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    if ($type !== null || $type !== "") {
            if ($type == "category" && $name !== null) {
                $sql = "INSERT INTO `expense_category` (`category_id`, `category_name`) VALUES (NULL, '$name')";
                $insertResult = $conn->query($sql);
                if (!$insertResult) {
                    jsonResponse(400, ['error' => $conn->error]);
                }else{
                    jsonResponse(200, ['success' => "Category Added"]);
                }
            } elseif ($type == "sub_category" && $name !== null && $category_id !== null) {
                $sql = "INSERT INTO `sub_category_expense` (`sub_name`, `category_id`) VALUES ('$name' , '$category_id')";
                $insertResult = $conn->query($sql);
                if (!$insertResult) {
                    jsonResponse(400, ['error' => $conn->error]);
                }else{
                    jsonResponse(200, ['success' => "Sub-Category Added"]);
                }
            }
        
    } else {
        jsonResponse(500, ['error' => 'Please mention the type']);
    }
}

//TO GET ALL THE CATEGORIES
if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    $sqlCategories = "
    SELECT * FROM expense_category";

    $resultExpenseCategories = $conn->query($sqlCategories);
    
    if (!$resultExpenseCategories) {
        die("Query for expense categories  failed: " . $conn->error);
    }
    
    $dataExpenseCategories = [];
    while ($row = $resultExpenseCategories->fetch_assoc()) {
        $dataExpenseCategories[] = $row;
    }

//-------------------------------------------------------------------------------

// Build the SQL query for sub categories
$sqlSubCategories = "SELECT * FROM sub_category_expense";

$resultSubCategories = $conn->query($sqlSubCategories);

if (!$resultSubCategories) {
    die("Query for sub categories failed: " . $conn->error);
}

$dataSubCategories = [];
while ($row = $resultSubCategories->fetch_assoc()) {
    $dataSubCategories[] = $row;
}

$conn->close();

echo json_encode(['expense_categories' => $dataExpenseCategories, 'sub_categories' => $dataSubCategories]);

}



?>