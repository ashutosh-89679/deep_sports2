<?php 
include 'ladderDb.php';


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
// Create a database connection using PDO
try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

$ladder_id = null;

// Get the JSON data from the request body
$json_data = file_get_contents('php://input');

// Decode the JSON data into an associative array
$data = json_decode($json_data, true);

// Check if data are set
if (isset($data['ladder_id'])) {
    $ladder_id = $data['ladder_id'];
}

if ($ladder_id !== null) {
    $sql = "SELECT ladder_stage, ladder_stage_start, ladder_stage_end, stage_percent FROM ladder WHERE ladder_id = '$ladder_id'";

    // Execute the SQL query
    $result = $pdo->query($sql);

    if ($result) {
        $data = $result->fetchAll(PDO::FETCH_ASSOC);

        // Modify the keys in the result array
        $output = array_map(function($item) {
            return [
                'stage' => $item['ladder_stage'],
                'min' => $item['ladder_stage_start'],
                'max' => $item['ladder_stage_end'],
                'percent' => $item['stage_percent']
            ];
        }, $data);

        // Output the modified data as JSON
        echo json_encode($output);
    } else {
        echo "Error: " . $sql;
    }
}

// Close the database connection
$pdo = null;
?>
