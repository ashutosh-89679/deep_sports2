<?php
// Database configuration (update with your database credentials)
include 'ladderDb.php';


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if (isset($_GET['file_type'])) {
        $file_type = $_GET['file_type'];
        $unique_id = $_GET['unique_id'];

        // Prepare an SQL statement to select the file data by ID
        $stmt = $pdo->prepare("SELECT file_name, file_data 
                              FROM files 
                              WHERE file_type = :file_type AND unique_id = :unique_id
                              ORDER BY created_at DESC
                              LIMIT 1;
                              ");
        $stmt->bindParam(':file_type', $file_type);
        $stmt->bindParam(':unique_id', $unique_id);

        // Execute the SQL statement
        if ($stmt->execute()) {
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($result) {
                // Set the appropriate content type for images
                header("Content-Type: image/jpeg");

                // Output the file data
                echo $result['file_data'];
                exit();
            } else {
                echo 'File not found';
            }
        } else {
            echo 'Database error';
        }
    } else {
        echo 'File ID not provided';
    }
} catch (PDOException $e) {
    echo 'Database error: ' . $e->getMessage();
}
?>
