<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'database.php';


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}



$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

function jsonResponse($statusCode, $data)
{
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
}

$booking_id = null;

if (isset($data['booking_id'])) {
    $booking_id = $data['booking_id'];
}

if (!empty($booking_id)) {

$sql = "SELECT ob.*, bd.closure_date AS ba1_date, bc.name FROM ob_status_records ob JOIN booking_details bd ON ob.booking_id = bd.booking_id JOIN booked_clients bc ON bd.client_id = bc.User_id WHERE ob.booking_id = ?";
    
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        jsonResponse(500, ['error' => 'Failed to prepare the query']);
        exit();
    }

    $stmt->bind_param("i", $booking_id);

    if ($stmt->execute()) {
        $result = $stmt->get_result();
        
        // Fetch the data from the result set
        $data = $result->fetch_all(MYSQLI_ASSOC);
        
        jsonResponse(200, ['data' => $data]);
    } else {
        jsonResponse(500, ['error' => 'Failed to execute the query']);
    }} 
    
    else {
    jsonResponse(400, ['error' => 'Client_id is empty']);
}
?>