<?php

// Replace these variables with your database connection details
$servername = "localhost";
$username = "aarnainw_ashutosh";
$password = "4PtX8dn]&m!-";
$dbname = "aarnainw_finance_main";

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}

$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

$start_date = isset($data['start_date']) ? $data['start_date'] : null;
$end_date = isset($data['end_date']) ? $data['end_date'] : null;
$company_id = isset($data['company_id']) ? $data['company_id'] : null;

//echo json_encode($data);


//echo $company_id;
//if($company_id !== null){
//    echo "it is not null";
//}

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "
    SELECT
        SUM(i.invoice_value) AS total_invoice_value,
        c.company_name,
        i.company_id,
        MONTHNAME(i.received_date) AS month,
        YEAR(i.received_date) AS year,
        CASE
            WHEN DAY(i.received_date) BETWEEN 1 AND 10 THEN '01_to_10'
            WHEN DAY(i.received_date) BETWEEN 11 AND 20 THEN '11_to_20'
            WHEN DAY(i.received_date) BETWEEN 21 AND 31 THEN '21_to_30'
            ELSE 'other'
        END AS day_range
    FROM
        invoice AS i
    JOIN
        company AS c ON i.company_id = c.company_id
    WHERE
        i.post_raise_id = 3";

if (isset($start_date) && isset($end_date) && $start_date !== "" && $end_date !== "") {
    $sql .= " WHERE i.received_date BETWEEN :start_date AND :end_date";
}

 $sql .= "
    GROUP BY
        i.company_id, day_range, month, year
    HAVING
        total_invoice_value > 0
    ";

if (isset($company_id) && $company_id !== "") {
    $sql .= "AND i.company_id IN ($company_id)";
}
error_log($sql);
$sql .= ";";



    $stmt = $conn->prepare($sql);
    
    // Bind parameters if they are set
    if (isset($start_date) && isset($end_date) && $start_date !== "" && $end_date !== "") {
        $stmt->bindParam(':start_date', $start_date);
        $stmt->bindParam(':end_date', $end_date);
    }
//error_log($sql);

    
    $stmt->execute();
    
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Organize data by company
    $organizedData = [];

    foreach ($result as $row) {
        $companyId = $row['company_id'];
        $companyName = $row['company_name'];
        $month = $row['month'];
        $dayRange = $row['day_range'];
        $totalInvoiceValue = $row['total_invoice_value'];

        // Create or update the company entry
        if (!isset($organizedData[$companyId])) {
            $organizedData[$companyId] = [
                'company_id' => $companyId,
                'company_name' => $companyName,
            ];
        }

        // Create or update the month entry for the company
        if (!isset($organizedData[$companyId][$month])) {
            $organizedData[$companyId][$month] = [
                0, 0, 0,
            ];
        }

        // Update the total_invoice_value for the specific day range
        switch ($dayRange) {
            case '01_to_10':
                $index = 0;
                break;
            case '11_to_20':
                $index = 1;
                break;
            case '21_to_30':
                $index = 2;
                break;
            default:
                $index = 0; 
        }
        
        $organizedData[$companyId][$month][$index] = $totalInvoiceValue;
    }

    // Fill in missing months with [0, 0, 0] for each company
    $allMonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

    foreach ($organizedData as &$companyData) {
        foreach ($allMonths as $month) {
            if (!isset($companyData[$month])) {
                $companyData[$month] = [
                    0, 0, 0,
                ];
            }
        }
    }

    // Convert the associative array to JSON
    $jsonResult = json_encode(array_values($organizedData), JSON_PRETTY_PRINT);

    // Output the JSON result
    echo $jsonResult;
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

$conn = null;

?>
