<?php
$servername = "localhost";
$username = "aarnainw_ashutosh";
$password = "4PtX8dn]&m!-";
$database = "aarnainw_finance_main";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}

$data = json_decode(file_get_contents("php://input"), true);

$projectFilter = isset($data['project_id']) ? $data['project_id'] : null;
$developerFilter = isset($data['developer_id']) ? $data['developer_id'] : null;
$branchFilter = isset($data['branch_id']) ? $data['branch_id'] : null;
$companyFilter = isset($data['company_id']) ? $data['company_id'] : null;
$submit_start_date = isset($data['submit_start_date']) ? $data['submit_start_date'] : null;
$submit_end_date = isset($data['submit_end_date']) ? $data['submit_end_date'] : null;

// Common part of the JOIN clause
$commonJoin = "JOIN invoice i ON c.company_id = i.company_id";
$commonCondition = "AND i.invoice_raise_date IS NOT NULL";
if ($submit_start_date !== null && $submit_end_date !== null) {
    $commonCondition = "AND i.invoice_raise_date IS NOT NULL AND i.invoice_raise_date BETWEEN '$submit_start_date' AND '$submit_end_date'";
}

$projects = [];
$developers = [];
$branches = [];
$companies = [];

$sql = '';

if ($projectFilter !== "") {
    $project_id = count(explode(",", $projectFilter));
    if ($project_id > 1) {
        $sql .= "SELECT
                'PROJECT' AS type,
                p.project_name AS name,
                SUM(i.invoice_value) AS net_revenue
             FROM
                project p
             JOIN
                company c ON p.company_id = c.company_id
             $commonJoin
             WHERE
                p.project_id IN ($projectFilter)
                $commonCondition
             GROUP BY
                p.project_name
             UNION ";
    }
}

if ($developerFilter !== "") {
    $developer_id = count(explode(",", $developerFilter));
    if ($developer_id > 1) {
        $sql .= "SELECT
                'DEVELOPER' AS type,
                d.developer_name AS name,
                SUM(i.invoice_value) AS net_revenue
             FROM
                developer d
             JOIN
                company c ON d.developer_id = c.developer_id
             $commonJoin
             WHERE
                d.developer_id IN ($developerFilter)
                $commonCondition
             GROUP BY
                d.developer_name
             UNION ";
    }
}

if ($branchFilter !== "") {
    $branch_id = count(explode(",", $branchFilter));
    if ($branch_id > 1) {
        $sql .= "SELECT
            'BRANCH' AS type,
            l.location_name AS name,
            SUM(i.invoice_value) AS net_revenue
         FROM
            location l
         JOIN
            developer d ON l.location_id = d.location_id
         JOIN
            company c ON d.developer_id = c.developer_id
         $commonJoin
         WHERE
            l.location_id IN ($branchFilter)
            $commonCondition
         GROUP BY
            l.location_name
         UNION ";
    }
}

if ($companyFilter !== "") {
    $company_id = count(explode(",", $companyFilter));
    if ($company_id > 1) {
        $sql .= "SELECT
                'COMPANY' AS type,
                c.company_name AS name,
                SUM(i.invoice_value) AS net_revenue
             FROM
                company c
             $commonJoin
             WHERE
                c.company_id IN ($companyFilter)
                $commonCondition
             GROUP BY
                c.company_name
             UNION ";
    }
}

file_put_contents('check.txt', $sql);


if (!empty($sql)) {
    $sql = rtrim($sql, "UNION ");
  //  echo "SQL Query: $sql"; // Add this line for debugging
}
$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {
    $type = $row['type'];
    $entry = [
        "name" => $row['name'],
        "net_revenue" => $row['net_revenue']
    ];

    switch ($type) {
        case 'PROJECT':
            $projects[] = $entry;
            break;
        case 'DEVELOPER':
            $developers[] = $entry;
            break;
        case 'BRANCH':
            $branches[] = $entry;
            break;
        case 'COMPANY':
            $companies[] = $entry;
            break;
    }
}

$output = [
    "PROJECT" => $projects,
    "DEVELOPER" => $developers,
    "BRANCH" => $branches,
    "COMPANY" => $companies
];

echo json_encode($output);
$conn->close();
?>
