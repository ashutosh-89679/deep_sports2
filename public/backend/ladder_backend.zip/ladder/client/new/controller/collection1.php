
<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once('db.php');
require_once('response.php');

function isValidDateFormat($dateString) {
    return strtotime($dateString) !== false;
}

try {
    $conn = connectToDatabase();
} catch (PDOException $ex) {
    error_log("Connection Error: " . print_r($ex, true), 0);
    $response = new Response();
    $response->setHttpStatusCode(500);
    $response->setSuccess(false);
    $response->addMessage("Database connection error");
    $response->send();
    exit;
}

$rawPatchdata = file_get_contents('php://input');
$data = json_decode($rawPatchdata, true);
$start_date = null;
$end_date = null;

if (!empty($rawPatchdata)) {
    $jsonData = json_decode($rawPatchdata);
    if (!$jsonData) {
        $response = new Response();
        $response->setHttpStatusCode(400);
        $response->setSuccess(false);
        $response->addMessage("Request body is not valid JSON");
        $response->send();
        exit;
    }
} else {
    $jsonData = new stdClass();
}

$sql = "SELECT
SUM(
    CASE WHEN i.raise_status_id = 1 THEN i.invoice_value
END
) AS net_revenue,
COUNT(
CASE WHEN i.raise_status_id = 1 THEN bd.client_id
END
) AS total_invoice_raised,
COUNT(
CASE WHEN i.raise_status_id = 1 AND i.post_raise_id = 1 THEN bd.client_id
END
) AS total_invoice_pending,
COUNT(
CASE WHEN i.post_raise_id = 2 AND i.expected_receive_date IS NULL THEN bd.client_id
END
) AS total_outstanding,
COUNT(
CASE WHEN i.post_raise_id = 3 THEN bd.client_id
END
) AS total_invoice_received,
COUNT(
CASE WHEN  i.post_raise_id = 4 THEN bd.client_id
END
) AS total_can,
SUM(bd.agreement_value) AS total_agreement_value,
COUNT(bd.booking_id) AS total_booking,
ROUND(
AVG(
    bd.base_brokerage + COALESCE(bd.ladder_stage, 0)
),
2
) AS average_brokerage,
SUM(
CASE WHEN i.post_raise_id = 3 THEN bd.agreement_value ELSE 0
END
) AS net_revenue,
SUM(
bd.agreement_value * bd.base_brokerage +(
    (
        bd.agreement_value * bd.base_brokerage
    ) * 18 / 100
) -(
    (
        bd.agreement_value * bd.base_brokerage
    ) * 5 / 100
) - COALESCE(bd.cashback_amount, 0)
) AS total_gross_amount,
SUM(
COALESCE(bd.cashback_amount, 0)
) AS total_cashback_amount
FROM
booking_details AS bd
JOIN invoice i ON
bd.client_id = i.client_id";

if (isset($data['start_date'])) {
    $start_date = $data['start_date'];
}

if (isset($data['end_date'])) {
    $end_date = $data['end_date'];
}

if ($start_date && $end_date) {
    if (isValidDateFormat($start_date) && isValidDateFormat($end_date)) {
        $sql .= " WHERE bd.closure_date BETWEEN :start_date AND :end_date";
    } else {
        $response = new Response();
        $response->setHttpStatusCode(400);
        $response->setSuccess(false);
        $response->addMessage("Incorrect date format. Both start_date and end_date should be valid dates.");
        $response->send();
        exit;
    }
}

try {
    $stmt = $conn->prepare($sql);

    if ($start_date && $end_date) {
        $stmt->bind_param('ss', $start_date, $end_date);
    }

    $stmt->execute();
    $result = $stmt->get_result();
    $data2 = $result->fetch_all(MYSQLI_ASSOC);

    if (!empty($data2) && $data2[0]["total_booking"] === "0") {
        $response = new Response();
        $response->setHttpStatusCode(400);
        $response->setSuccess(true);
        $response->addMessage("Results are empty. Please check the dates that you have passed.");
        $response->send();
        exit;
    } else {
        $response = new Response();
        $response->setHttpStatusCode(200);
        $response->setSuccess(true);
        $response->addMessage("Got results");
        $response->setData($data2);
        $response->send();
    }

} catch (PDOException $ex) {
    error_log("Error: " . print_r($ex, true), 0);
    $response = new Response();
    $response->setHttpStatusCode(500);
    $response->setSuccess(false);
    $response->addMessage("An error occurred");
    $response->send();
    exit;
}
?>
