<?php
$servername = "localhost";
$username = "aarnainw_ashutosh";
$password = "4PtX8dn]&m!-";
$database = "aarnainw_finance_main";

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$page = isset($_GET['page']) ? max(1, $_GET['page']) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

$daysFilter = isset($data['days']) ? $data['days'] : null;
$projectFilter = isset($data['project_id']) ? $data['project_id'] : null;
$developerFilter = isset($data['developer_id']) ? $data['developer_id'] : null;
$branchFilter = isset($data['branch_id']) ? $data['branch_id'] : null;


$companyFilter = isset($data['company_id']) ? $data['company_id'] : null;
$submit_start_date = isset($data['submit_start_date']) ? $data['submit_start_date'] : null;
$submit_end_date = isset($data['submit_end_date']) ? $data['submit_end_date'] : null;

$data = [];
$filterArrayData = [];

//Filter By Project
if($projectFilter !== null){
    $getByProject = "SELECT company_id FROM project WHERE project_id IN ($projectFilter)";
    $getByProjectResult = $conn->query($getByProject);

   if ($getByProjectResult) {
       while ($row = $getByProjectResult->fetch_assoc()) {
                $filterArrayData[] = $row['company_id'];
       }
       
   } else {
       echo json_encode(['error' => 'Query execution failed']);
     }
}

//Filter By Developer
if($developerFilter !== null){
    $getByDeveloper = "SELECT company_id FROM company WHERE developer_id IN ($developerFilter)";
    $getByDeveloperResult = $conn->query($getByDeveloper);

   if ($getByDeveloperResult) {
       while ($row = $getByDeveloperResult->fetch_assoc()) {
                $filterArrayData[] = $row['company_id'];
       }
       
   } else {
       echo json_encode(['error' => 'Query execution failed']);
     }
}

if($branchFilter !== null){
    $getByBranchFilter = "SELECT DISTINCT c.company_id
    FROM company c
    JOIN developer d ON c.developer_id = d.developer_id
    WHERE d.location_id IN ($branchFilter);";
    $getByBranchResult = $conn->query($getByBranchFilter);

   if ($getByBranchResult) {
       while ($row = $getByBranchResult->fetch_assoc()) {
                $filterArrayData[] = $row['company_id'];
       }
       
   } else {
       echo json_encode(['error' => 'Query execution failed']);
     }
}

if($companyFilter !== null){
    $getByCompanyFilter = "SELECT DISTINCT company_id
    FROM company 
    WHERE company_id IN ($companyFilter);";
    $getByCompanyResult = $conn->query($getByCompanyFilter);

   if ($getByCompanyResult) {
       while ($row = $getByCompanyResult->fetch_assoc()) {
                $filterArrayData[] = $row['company_id'];
       }
       
   } else {
       echo json_encode(['error' => 'Query execution failed']);
     }
}


/* if($projectFilter !== null){
    echo json_encode($filterArrayData);
}

if($developerFilter !== null){
    echo json_encode($filterArrayData);
}

if($branchFilter !== null){
    echo json_encode($filterArrayData);
} */

$filterArrayDataUnique = null;

if ($filterArrayData !== null){
$filterArrayDataUnique = implode(',', array_unique($filterArrayData));
}


if ($page === 1) {
    // Query to get the count of records only on page 1
    $countSql = "
        SELECT COUNT(*) AS total_count
        FROM invoice AS i
        INNER JOIN company_estimation AS ce ON i.company_id = ce.company_id
        WHERE post_raise_id IN (2, 3)";

    if ($daysFilter !== null) {
    $daysRange = explode(' - ', $daysFilter);

    if (count($daysRange) === 2 && is_numeric($daysRange[0]) && is_numeric($daysRange[1])) {
        $startDay = intval($daysRange[0]);
        $endDay = intval($daysRange[1]);

        // Modify the SQL query
        $countSql .= " AND DATEDIFF(CURDATE(), i.submit_date) BETWEEN $startDay AND $endDay";
    } else {
        // Handle invalid format
        echo json_encode(['error' => 'Invalid daysFilter format']);
        }
    }


    if (!empty($filterArrayDataUnique)) {
        $countSql .= " AND i.company_id IN ($filterArrayDataUnique)";
    }


    if ($submit_start_date !== null && $submit_end_date !== null) {
        $countSql .= " AND i.submit_date BETWEEN '$submit_start_date' AND '$submit_end_date'";
    }

    $countResult = $conn->query($countSql);

    if (!$countResult) {
        die("Count query failed: " . $conn->error);
    }

    $countRow = $countResult->fetch_assoc();
    $totalCount = $countRow['total_count'];

    // Add total_count to the result only on page 1
    $data['total_count'] = ['count' => $totalCount];
}

// Main query to get records with limit and offset
$sql = "
        SELECT
        i.invoice_number,
        i.submit_date,
        i.invoice_receive_date,
        com.company_name,
        i.company_id,
        DATEDIFF(CURDATE(), i.submit_date) AS days_interval,
        i.submit_date + INTERVAL ce.commited_days DAY AS expected_date
        FROM
        invoice AS i
        INNER JOIN
        company_estimation AS ce ON i.company_id = ce.company_id
        INNER JOIN
        company  AS com ON i.company_id = com.company_id 
        WHERE
        post_raise_id IN (2, 3) AND submit_date IS NOT NULL";

    if ($daysFilter !== null) {
    $daysRange = explode(' - ', $daysFilter);

    if (count($daysRange) === 2 && is_numeric($daysRange[0]) && is_numeric($daysRange[1])) {
        $startDay = intval($daysRange[0]);
        $endDay = intval($daysRange[1]);

        // Modify the SQL query
        $countSql .= " AND DATEDIFF(CURDATE(), i.submit_date) BETWEEN $startDay AND $endDay";
    } else {
        // Handle invalid format
        echo json_encode(['error' => 'Invalid daysFilter format']);
        }
    }


if (!empty($filterArrayDataUnique)) {
    $sql .= " AND i.company_id IN ($filterArrayDataUnique)";
}


if ($submit_start_date !== null && $submit_end_date !== null) {
    $sql .= " AND i.submit_date BETWEEN '$submit_start_date' AND '$submit_end_date'";
}

$sql .= " LIMIT $limit OFFSET $offset";

$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}

while ($row = $result->fetch_assoc()) {
    $projectId = $row['company_id'];
    $projectNameQuery = "SELECT project_name FROM project WHERE company_id = '$projectId'";
    $projectNameResult = $conn->query($projectNameQuery);

    if (!$projectNameResult) {
        die("Project name query failed: " . $conn->error);
    }

    $projectNameRow = $projectNameResult->fetch_assoc();

    $row['project_name'] = $projectNameRow['project_name'];
    $data[] = $row;
}

$conn->close();

// Ensure the result is always returned as an array
echo json_encode(array_values($data));
?>