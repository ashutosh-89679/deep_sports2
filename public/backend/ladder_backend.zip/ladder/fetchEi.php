<?php
// Database configuration (update with your database credentials)
include 'ladderDb.php';


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}


// Create a database connection using PDO
try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

$start_date = null;
$end_date = null;
$search_project_id = null;

$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

if (isset($data['search_project_id'])) {
    $search_project_id = $data['search_project_id'];
}

if (isset($data['search_start_date'])) {
    $start_date = $data['search_start_date'];
}

if (isset($data['search_end_date'])) {
    $end_date = $data['search_end_date'];
}


// Query to fetch ei_ids from project_ei
$query = "SELECT DISTINCT ei_id FROM project_ei ";
$stmt = $pdo->prepare($query);
$stmt->execute();

// Fetch ei_ids into an array
$eiIds = $stmt->fetchAll(PDO::FETCH_COLUMN);
$eiIds = array_unique($eiIds);

// Construct the SQL query
$sql = "
SELECT
    pe.relation_id AS relationid,
    e.ei_tenure_start_date AS start_date,
    e.ei_tenure_end_date AS end_date,
    e.ei_extended_date AS extended_date,
    e.ei_target_amount AS target_amount,
    e.ei_conditon AS ei_condition,
    e.ei_target_unit AS target_unit,
    e.ei_percent AS target_percent,
    e.ei_value AS ei_value,
    pe.ei_id,
    p.project_name,
    d.developer_name
FROM ei e
JOIN project_ei pe ON e.ei_unique_id = pe.ei_id
JOIN project p ON pe.project_id = p.project_id
JOIN company c ON p.company_id = c.company_id
JOIN developer d ON c.developer_id = d.developer_id
WHERE e.ei_unique_id IN ('" . implode("', '", $eiIds) . "')
";

if (!empty($search_project_id)) {
    $sql .= " AND pe.project_id IN ($search_project_id)";
}

if ($start_date !== null && $end_date !== null) {
$sql .= " AND (e.ei_tenure_start_date BETWEEN :start_date AND :end_date 
          OR :start_date AND :end_date BETWEEN e.ei_tenure_start_date AND e.ei_tenure_end_date
          OR e.ei_extended_date BETWEEN :start_date AND :end_date)";
}

// Group the results as in your original query
$sql .= " GROUP BY pe.relation_id, e.ei_tenure_start_date, e.ei_tenure_end_date, pe.ei_id, pe.project_id, p.project_name, c.company_id, d.developer_name";

$sql .= " ORDER BY start_date DESC, end_date DESC";

// Prepare and execute the SQL query with date range parameters
$stmt = $pdo->prepare($sql);
if ($start_date !== null && $end_date !== null) {
    $stmt->bindParam(':start_date', $start_date);
    $stmt->bindParam(':end_date', $end_date);
}
$stmt->execute();

// Fetch and output the data as JSON
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($data);

// Close the database connection
$pdo = null;
?>
