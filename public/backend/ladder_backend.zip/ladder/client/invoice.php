<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'database.php';


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS , PUT"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH, PUT");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}


$currentDate = date("Y-m-d");

// Function to handle JSON response
function jsonResponse($statusCode, $data)
{
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
}

// Get the JSON data from the request body
$json_data = file_get_contents('php://input');

// Decode the JSON data into an associative array
$data = json_decode($json_data, true);

$received_date = null;
$cancel_date = null;
$invoice_receive_date = null;
$post_status_id = null;

// Check if data are set
if (isset($data['company_id'])) {
    $company_id = $data['company_id'];
}

if (isset($data['invoice_number'])) {
    $invoice_number = $data['invoice_number'];
}

if (isset($data['submit_date'])) {
    $submit_date = $data['submit_date'];
}

if (isset($data['received_date'])) {
    $received_date = $data['received_date'];
}

if (isset($data['cancel_date'])) {
    $cancel_date = $data['cancel_date'];
}

if (isset($data['invoice_value'])) {
    $invoice_value = $data['invoice_value'];
}

if (isset($data['invoice_type'])) {
    $invoice_type = $data['invoice_type'];
}

if (isset($data['invoice_receive_date'])) {
    $invoice_receive_date = $data['invoice_receive_date'];
}

if(isset($data['expected_receive_date'])){
    $expected_receive_date = $data['expected_receive_date'];
}

if (isset($data['client_id'])) {
    $client_id = $data['client_id'];
}
if (isset($data['raise_status_id'])) {
    $raise_status_id = $data['raise_status_id'];
}

if (isset($data['raise_date'])) {
    $raise_date = $data['raise_date'];
}

if (isset($data['post_status_id'])) {
    $post_status_id = $data['post_status_id'];
}

if (isset($data['cancel_reason'])) {
    $cancel_reason = $data['cancel_reason'];
}

if (isset($data['cancel_type'])) {
    $cancel_type = $data['cancel_type'];
}


if ($_SERVER['REQUEST_METHOD'] === 'PUT') {

    // Define the SQL query for inserting data
     $sql = "INSERT INTO `invoice` (`company_id`, `client_id`, `invoice_number` , `post_raise_id`, `raise_status_id` , `invoice_raise_date` , `invoice_value` , `invoice_type`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
     
     // Prepare the SQL statement
     $stmt = $conn->prepare($sql);
     
     // Assuming $company_id, $client_id, $invoice_number, $currentDate, $invoice_value are your variables
     // Create variables for constant values
     $post_raise_id1 = '1';
     $raise_status_id1 = '1';
     
     // Bind the parameters using bind_param
     $stmt->bind_param('iisissss', $company_id, $client_id, $invoice_number, $post_raise_id1, $raise_status_id1, $raise_date, $invoice_value, $invoice_type);


    // Execute the SQL statement
    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();
        jsonResponse(200, ['message' => 'Data inserted successfully.']);
    } else {
        // Capture and display the SQL error
        $error = [
            'error' => 'Data insertion failed',
            'sql_error' => $stmt->error, 
        ];
        $stmt->close();
        $conn->close();
        jsonResponse(500, $error);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if invoice_number is provided
    if (!empty($invoice_number) || $invoice_number !== null) {
        $sql = "UPDATE `invoice` SET";
        $updateStatements = [];
    
        if (!empty($received_date)) {
            $updateStatements[] = "`received_date` = ?";
        }
    
        if (!empty($submit_date)) {
            $updateStatements[] = "`submit_date` = ?";
        }
    
        if (!empty($cancel_date)) {
            $updateStatements[] = "`cancellation_date` = ?";
        }
        
        if(!empty($cancel_reason)){
            $updateStatements[] = "`cancel_reason` = ?";
        }
        
        if(!empty($cancel_type)){
            $updateStatements[] = "`cancel_type` = ?";
        }


        if(!empty($expected_receive_date)){
            $updateStatements[] = "`expected_receive_date` = ?";
        }
    
        if (!empty($post_status_id)) {
            $updateStatements[] = "`post_raise_id` = ?";
        }
    
        $sql .= implode(", ", $updateStatements);
        $sql .= " WHERE `client_id` = ? AND `invoice_number` = ?";
        $stmt = $conn->prepare($sql);
        $bindValues = [];
    
        if (!empty($received_date)) {
            $bindValues[] = $received_date;
        }
    
        if (!empty($submit_date)) {
            $bindValues[] = $submit_date;
        }
    
        if (!empty($cancel_date)) {
            $bindValues[] = $cancel_date;
        }
        
         if(!empty($cancel_reason)){
             $bindValues[] = $cancel_reason;
         }
         
         if(!empty($cancel_type)){
             $bindValues[] = $cancel_type;
         }
    
        if (!empty($expected_receive_date)) {
            $bindValues[] = $expected_receive_date;
        }
        
        if (!empty($post_status_id)) {
            $bindValues[] = $post_status_id;
        }
    
        $bindValues[] = $client_id;
        $bindValues[] = $invoice_number;
    
        $stmt->bind_param(str_repeat('s', count($bindValues)), ...$bindValues);
    
        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                $stmt->close();
                $conn->close();
                jsonResponse(200, ['message' => 'Data Updated successfully.']);
            } else {
                $stmt->close();
                $conn->close();
                jsonResponse(500, ['error' => 'Cannot set to the previous stage']);
            }
        } else {
            $error = [
                'error' => 'Data updation failed',
                'sql_error' => $stmt->error,
            ];
            $stmt->close();
            $conn->close();
            jsonResponse(500, $error);
        }
    }
     else {
        jsonResponse(500, ['message' => 'Please pass the invoice number for updating the invoice.']);
    }
}


?>