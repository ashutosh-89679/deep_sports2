<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'database.php';


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS , PUT"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH, PUT");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}



// Define SQL queries for each table
$tableQueries = [
    "performa" => "SELECT MAX(invoice_number) AS invnumber FROM invoice WHERE invoice_type = 'performa'",
    "tax" => "SELECT MAX(invoice_number) AS invnumber FROM invoice WHERE invoice_type = 'tax'",
    "advance" => "SELECT MAX(invoice_number) AS invnumber FROM invoice WHERE invoice_type = 'advance'"
];

// Execute queries and store results in an associative array
$data = [];

foreach ($tableQueries as $tableName => $query) {
    $result = $conn->query($query);

    if ($result) {
        $tableData = [];

        while ($row = $result->fetch_assoc()) {
            $tableData[] = $row;
        }

        $data[$tableName] = $tableData;
    } else {
        // Handle query errors
        $data[$tableName] = "Error: " . $conn->error;
    }
}

// Return the data as JSON
header('Content-Type: application/json');
echo json_encode($data);

// Close the database connection
$conn->close();
?>


