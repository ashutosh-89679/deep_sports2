<?php
// Database connection settings
include 'ladderDb.php';


error_reporting(E_ALL);
ini_set('display_errors', 1);

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}



$type = null;
$name = null;
$refrence_id = null;
$refrence_id2 = null;

$json_data = file_get_contents('php://input');

$data = json_decode($json_data, true);

if (isset($data['type'])) {
    $type = $data['type'];
}

if (isset($data['name'])) {
    $name = $data['name'];
}

if (isset($data['refrence_id'])) {
    $refrence_id = $data['refrence_id'];
}

if (isset($data['refrence_id2'])) {
    $refrence_id2 = $data['refrence_id2'];
}

if ($type == "location" && !empty($name)) {
    $sqlQuery = "INSERT INTO location (location_id, location_name)
                 SELECT COALESCE(MAX(location_id), 0) + 1, '$name'
                 FROM location;
                ";

    $result = $connection->query($sqlQuery);

    if ($result) {
        echo json_encode(["success" => "Record added successfully"]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Error adding the record: " . $connection->error]);
    }
}

if ($type == "locality" && !empty($name)) {
    $sqlQuery = "INSERT INTO locality (locality_name, location_id) VALUES ('$name' , '$refrence_id')";

    $result = $connection->query($sqlQuery);

    if ($result) {
        echo json_encode(["success" => "Record added successfully"]);
    } else {
        echo json_encode(["error" => "Error adding the record: " . $connection->error]);
    }
}

if ($type == "developer" && !empty($name)) {
    $sqlQuery = "INSERT INTO developer (developer_id, developer_name)
                 SELECT COALESCE(MAX(developer_id), 0) + 1, '$name'
                 FROM developer;
                ";

    $result = $connection->query($sqlQuery);

    if ($result) {
        echo json_encode(["success" => "Record added successfully"]);
    } else {
        echo json_encode(["error" => "Error adding the record: " . $connection->error]);
    }
}

if ($type == "company" && !empty($name)) {
    $sqlQuery = "INSERT INTO company (company_id, company_name , developer_id)
                 SELECT COALESCE(MAX(company_id), 0) + 1, '$name', '$refrence_id'
                 FROM company;
                ";

    $result = $connection->query($sqlQuery);

    if ($result) {
        echo json_encode(["success" => "Record added successfully"]);
    } else {
        echo json_encode(["error" => "Error adding the record: " . $connection->error]);
    }
}

if ($type == "project" && !empty($name)) {
    if ($refrence_id2 !== null) {
        $sqlQuery = "INSERT INTO project (project_id, project_name , company_id , locality_id)
                     SELECT COALESCE(MAX(project_id), 0) + 1, '$name', '$refrence_id' , '$refrence_id2'
                     FROM project;
                    ";

        $result = $connection->query($sqlQuery);

        if ($result) {
            echo json_encode(["success" => "Record added successfully"]);
        } else {
            echo json_encode(["error" => "Error adding the record: " . $connection->error]);
        }
    } else {
        echo json_encode(["error" => "Please provide a localityID"]);
    }
}

// Close the database connection
$connection->close();
?>
