<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$dbHost = "localhost";
$dbUsername = "aarnainw_ashutosh";
$dbPassword = "4PtX8dn]&m!-";
$dbName = 'aarnainw_finance_main'; 

// Function to establish a database connection
function connectToDatabase() {
    global $dbHost, $dbUsername, $dbPassword, $dbName;
    $conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}


$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

function calculatePercentage($numerator, $denominator) {
    if ($denominator == 0) {
        return 0;
    }
    $percentage = ($numerator / $denominator) * 100;
    return $percentage;
}

$conn = connectToDatabase();

$kicker_id = null;
$ei_id = null;



function updateBookingDetails($conn, $data) {
    $ladder_stage = $data['ladder_stage'];
    $ladder_idA = $data['ladder_id'];
    $base_brokerage = $data['base_brokerage'];
    $booking_id = $data['booking_id'];
    $kicker_percent = $data['kicker_percent'];
    $kicker_value = $data['kicker_value'];
    $ei_percent = $data['ei_percent'];
    $ei_value = $data['ei_value'];

    // Use prepared statements to handle NULL values
    $stmt = $conn->prepare("UPDATE booking_details
                            SET ladder_stage = ?,
                                base_brokerage = ?,
                                kicker_percent = ?,
                                kicker_value = ?,
                                ei_percent = ?,
                                ei_value = ?,
                                ladder_id = ?
                            WHERE booking_id = ?");

    // Bind parameters
$stmt->bind_param("ssssssss", $ladder_stage, $base_brokerage, $kicker_percent, $kicker_value, $ei_percent, $ei_value, $ladder_idA, $booking_id);

    if ($stmt->execute()) {
        echo "Record updated successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}



$bookingIdQuery = "SELECT
                bd.booking_id,
                bd.project_id,
                bd.closure_date,
                bd.agreement_value,
                pl.ladder_id,
                pk.kicker_id,
                pe.ei_id
                FROM
                booking_details bd
                JOIN project_ladder pl ON
                bd.project_id = pl.project_id
                LEFT JOIN project_kicker pk ON
                bd.project_id = pk.project_id
                LEFT JOIN project_ei pe ON
                bd.project_id = pe.project_id";

$resultBookingQuery = $conn->query($bookingIdQuery);

$actualResultArray = array();

if ($resultBookingQuery) {
    while ($bookingIdRow = $resultBookingQuery->fetch_assoc()) {
        $bookingId = $bookingIdRow["booking_id"];
        $project_id = $bookingIdRow["project_id"];
        $closure_date = $bookingIdRow["closure_date"];
        $agreement_value = $bookingIdRow["agreement_value"];
        $ladder_id = $bookingIdRow["ladder_id"];
        $kicker_id = $bookingIdRow["kicker_id"];
        $ei_id = $bookingIdRow["ei_id"];

        $actualResultArray[$bookingId] = array(
            "ladder_id" => $ladder_id,
            "ladder_stage" => null,
            "base_brokerage" => null,
            "booking_id" => null,
            "kicker_percent" => null,
            "kicker_value" => null,
            "ei_percent" => null,
            "ei_value" => null,
        );

        $ladder_percent = "SELECT stage_percent AS ladder_stage
                            FROM ladder
                            WHERE ladder_start_date <= '$closure_date'
                            AND ladder_end_date >= '$closure_date'
                            AND ladder_id = '$ladder_id'
                            AND (
                                SELECT COUNT(project_id) 
                                FROM booking_details
                                WHERE project_id = '$project_id'
                                AND ladder_stage_start <= (
                                    SELECT COUNT(project_id)
                                    FROM booking_details
                                    WHERE project_id = '$project_id'
                                )
                                AND ladder_stage_end >= (
                                    SELECT COUNT(project_id)
                                    FROM booking_details
                                    WHERE project_id = '$project_id'
                                )
                            )
                            ";
        $base_brokerage_sql = "SELECT stage_percent AS base_brokerage FROM `ladder` WHERE  ladder_stage = 0 AND ladder_id = '$ladder_id'";

        if ($kicker_id !== null) {
            $kicker_sql = "SELECT
                    k.kicker_in_percent AS kicker_percent,
                    k.kicker_in_value AS kicker_value 
                FROM
                    kicker k
                JOIN (
                    SELECT 
                        project_id,
                        SUM(agreement_value) AS total_cost,
                        COUNT(DISTINCT client_id) AS total_users
                    FROM
                        booking_details
                    WHERE
                        project_id = '$project_id'
                    GROUP BY
                        project_id
                ) b 
                WHERE
                    k.kicker_unique_id = '$kicker_id'
                    AND '$closure_date' BETWEEN k.kicker_start_date AND k.kicker_end_date
                    AND (
                        CASE 
                            WHEN k.kicker_condition = 'AND' THEN 
                                b.total_cost >= k.Kicker_target_in_amount AND b.total_users >= k.Kicker_target_in_unit
                            WHEN k.kicker_condition = 'OR' THEN 
                                b.total_cost >= k.Kicker_target_in_amount OR b.total_users >= k.Kicker_target_in_unit
                        END
                    )";

            $result_kicker = $conn->query($kicker_sql);
            $result_kicker_percent = $result_kicker->fetch_assoc();

            $actualResultArray[$bookingId]["kicker_percent"] = isset($result_kicker_percent['kicker_percent']) ? $result_kicker_percent['kicker_percent'] : null;
            $actualResultArray[$bookingId]["kicker_value"] = isset($result_kicker_percent['kicker_value']) ? $result_kicker_percent['kicker_value'] : null;
        }

        if ($ei_id !== null) {
            $ei_sql = "SELECT
                    e.ei_percent AS ei_percent,
                    e.ei_value AS ei_value
                FROM
                    ei e
                JOIN(
                    SELECT project_id,
                        SUM(agreement_value) AS total_cost,
                        COUNT(DISTINCT client_id) AS total_users
                    FROM
                        booking_details
                    WHERE
                        project_id = '$project_id'
                    GROUP BY
                        project_id
                ) b
                ON
                    e.ei_unique_id = '$ei_id'
                WHERE
                    e.ei_unique_id = '$ei_id'
                    AND (
                        CASE 
                            WHEN e.ei_conditon = 'AND' THEN 
                                b.total_cost >= e.ei_target_amount AND b.total_users >= e.ei_target_unit
                            WHEN e.ei_conditon = 'OR' THEN 
                                b.total_cost >= e.ei_target_amount OR b.total_users >= e.ei_target_unit
                        END
                    )
                    AND '$closure_date' BETWEEN e.ei_tenure_start_date AND e.ei_tenure_end_date";
                    
            $result_ei = $conn->query($ei_sql);
            $result_ei_percent = $result_ei->fetch_assoc();

            $actualResultArray[$bookingId]["ei_percent"] = isset($result_ei_percent['ei_percent']) ? $result_ei_percent['ei_percent'] : null;
            $actualResultArray[$bookingId]["ei_value"] = isset($result_ei_percent['ei_value']) ? $result_ei_percent['ei_value'] : null;
        }

        $result_ladder_percent = $conn->query($ladder_percent);
        $result_brokerage = $conn->query($base_brokerage_sql);

        $result_ladder_percent2 = $result_ladder_percent->fetch_assoc();
        $result_brokerage_percent = $result_brokerage->fetch_assoc();

        $actualResultArray[$bookingId]["ladder_stage"] = $result_ladder_percent2['ladder_stage'];
        $actualResultArray[$bookingId]["base_brokerage"] = $result_brokerage_percent['base_brokerage'];
        $actualResultArray[$bookingId]["booking_id"] = $bookingId;

        echo json_encode($actualResultArray[$bookingId]);
        $conn = connectToDatabase();

        // Call the function to insert data
        updateBookingDetails($conn, $actualResultArray[$bookingId]);

    }
}
?>
