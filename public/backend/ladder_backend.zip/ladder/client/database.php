<?php

$servername = "localhost";
$username = "aarnainw_ashutosh";
$password = "4PtX8dn]&m!-";
$database = 'aarnainw_finance_main';

$conn = new mysqli($servername, $username, $password, $database);

?>