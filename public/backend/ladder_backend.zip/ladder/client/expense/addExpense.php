<?php

$servername = "localhost";
$username = "aarnainw_ashutosh";
$password = "4PtX8dn]&m!-";
$database = "aarnainw_finance_main";

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}


$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


function insertExpense($file_name, $file_data, $file_type, $submit_date, $desc, $category_id, $amount, $branch_id, $sub_category_id) {
    global $conn;

    $stmt = $conn->prepare("INSERT INTO `expense` 
        (`file_name`, `file_data`, `file_type`, `submit_date`, `desc`, `category_id`, `amount`, `branch_id`, `sub_category_id`) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $stmt->bind_param("sssssiisi", $file_name, $file_data, $file_type, $submit_date, $desc, $category_id, $amount, $branch_id, $sub_category_id);

    $stmt->execute();

    if ($stmt->error) {
        die("Error: " . $stmt->error);
    }

    $stmt->close();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $file_name = $_FILES["file"]["name"];
    $file_data = file_get_contents($_FILES["file"]["tmp_name"]);
    $file_type = $_FILES["file"]["type"];
    $submit_date = $_POST["submit_date"];
    $desc = $_POST["desc"];
    $category_id = $_POST["category_id"];
    $amount = $_POST["amount"];
    $branch_id = $_POST["branch_id"];
    $sub_category_id = $_POST["sub_category_id"];

    insertExpense($file_name, $file_data, $file_type, $submit_date, $desc, $category_id, $amount, $branch_id, $sub_category_id);
}

$conn->close();

?>


