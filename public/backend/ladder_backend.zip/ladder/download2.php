<?php
// Database configuration (update with your database credentials)
include 'ladderDb.php';


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");


if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');   
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}

try {
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if (isset($_GET['file_type'])) {
        $file_type = $_GET['file_type'];
        $master_type = $_GET['master_type'];
        $unique_id = $_GET['unique_id'];
        
        
        //IF EXTENDED LADDER
        if($master_type == "ladder" && $file_type == "extended"){
            $jsonString = json_encode($file_type);
        file_put_contents('newcheck.txt', $jsonString, FILE_APPEND);

        // Updated SQL query with a simple join when $master_type is "ladder"
        $stmt = $pdo->prepare("
            SELECT files.file_name, files.file_data, ladder.ladder_start_date, ladder.ladder_extended_date
            FROM files
            LEFT JOIN ladder ON files.unique_id = ladder.ladder_id
            WHERE files.file_type = :file_type AND files.unique_id = :unique_id
            ORDER BY files.created_at DESC
            LIMIT 1;
        ");

            $stmt->bindParam(':file_type', $file_type);
            $stmt->bindParam(':unique_id', $unique_id);
            
            // Execute the SQL statement
            if ($stmt->execute()) {
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            }

            // Execute the SQL statement
            if ($result) {
                    // Set the appropriate content type (e.g., for images)
                    header("Content-Type: image/jpeg");
            
                    // Extract the filename without extension
                    $filenameWithoutExtension = pathinfo($result['file_name'], PATHINFO_FILENAME);
            
                    // Construct the filename with extracted filename, ladder_start_date_to_ladder_end_date
                    $filename = $filenameWithoutExtension . '_' . $result['ladder_start_date'] . '_to_' . $result['ladder_extended_date'] . '.jpg';
            
                    // Set the Content-Disposition header with the constructed filename
                    header("Content-Disposition: attachment; filename=\"$filename\"");
            
                    // Output the file data
                    echo $result['file_data'];
                    // You can also access ladder_start_date and ladder_end_date from $result array if needed
            
                    exit();
                }
            else {
                echo 'Database error';
            }
        }
        
        //IF MASTER TYPE IS LADDER
        elseif($master_type == "ladder"){

        // Updated SQL query with a simple join when $master_type is "ladder"
        $stmt = $pdo->prepare("
            SELECT files.file_name, files.file_data, ladder.ladder_start_date, ladder.ladder_end_date
            FROM files
            LEFT JOIN ladder ON files.unique_id = ladder.ladder_id
            WHERE files.file_type = :file_type AND files.unique_id = :unique_id
            ORDER BY files.created_at DESC
            LIMIT 1;
        ");

            $stmt->bindParam(':file_type', $file_type);
            $stmt->bindParam(':unique_id', $unique_id);
            
            // Execute the SQL statement
            if ($stmt->execute()) {
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            }

            // Execute the SQL statement
            if ($result) {
                    // Set the appropriate content type (e.g., for images)
                    header("Content-Type: image/jpeg");
            
                    // Extract the filename without extension
                    $filenameWithoutExtension = pathinfo($result['file_name'], PATHINFO_FILENAME);
            
                    // Construct the filename with extracted filename, ladder_start_date_to_ladder_end_date
                    $filename = $filenameWithoutExtension . '_' . $result['ladder_start_date'] . '_to_' . $result['ladder_end_date'] . '.jpg';
            
                    // Set the Content-Disposition header with the constructed filename
                    header("Content-Disposition: attachment; filename=\"$filename\"");
            
                    // Output the file data
                    echo $result['file_data'];
                    // You can also access ladder_start_date and ladder_end_date from $result array if needed
            
                    exit();
                }
            else {
                echo 'Database error';
            }
        }
        
        //IF EXTENDED KICKER
        if($master_type == "kicker" && $file_type == "extended"){
            
        $stmt = $pdo->prepare("
            SELECT files.file_name, files.file_data, kicker.kicker_start_date, kicker.kicker_extended_date 
            FROM files
            LEFT JOIN kicker ON files.unique_id = kicker.kicker_unique_id
            WHERE files.file_type = :file_type AND files.unique_id = :unique_id
            ORDER BY files.created_at DESC
            LIMIT 1;
        ");

            $stmt->bindParam(':file_type', $file_type);
            $stmt->bindParam(':unique_id', $unique_id);

            // Execute the SQL statement
            if ($stmt->execute()) {
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($result) {
                    // Set the appropriate content type (e.g., for images)
                header("Content-Type: image/jpeg");
                
                    // Extract the filename without extension
                    $filenameWithoutExtension = pathinfo($result['file_name'], PATHINFO_FILENAME);
                
                    // Construct the filename with extracted filename, kicker_start_date_to_kicker_end_date
                    $filename = $filenameWithoutExtension . '_' . $result['kicker_start_date'] . '_to_' . $result['kicker_extended_date'] . '.jpg';
                
                    // Set the Content-Disposition header with the constructed filename
                    header("Content-Disposition: attachment; filename=\"$filename\"");
                
                    // Output the file data
                    echo $result['file_data'];
                    // You can also access kicker_start_date and kicker_end_date from $result array if needed
                
                    exit();
                } else {
                echo 'File not found';
             }
            } 
            else {
                echo 'Database error';
            }
            
        }
        
        //IF MASTER TYPE IS KICKER
        elseif($master_type == "kicker"){
        $stmt = $pdo->prepare("
            SELECT files.file_name, files.file_data, kicker.kicker_start_date, kicker.kicker_end_date
            FROM files
            LEFT JOIN kicker ON files.unique_id = kicker.kicker_unique_id
            WHERE files.file_type = :file_type AND files.unique_id = :unique_id
            ORDER BY files.created_at DESC
            LIMIT 1;
        ");

            $stmt->bindParam(':file_type', $file_type);
            $stmt->bindParam(':unique_id', $unique_id);

            // Execute the SQL statement
            if ($stmt->execute()) {
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($result) {
                    // Set the appropriate content type (e.g., for images)
                header("Content-Type: image/jpeg");
                
                    // Extract the filename without extension
                    $filenameWithoutExtension = pathinfo($result['file_name'], PATHINFO_FILENAME);
                
                    // Construct the filename with extracted filename, kicker_start_date_to_kicker_end_date
                    $filename = $filenameWithoutExtension . '_' . $result['kicker_start_date'] . '_to_' . $result['kicker_end_date'] . '.jpg';
                
                    // Set the Content-Disposition header with the constructed filename
                    header("Content-Disposition: attachment; filename=\"$filename\"");
                
                    // Output the file data
                    echo $result['file_data'];
                    // You can also access kicker_start_date and kicker_end_date from $result array if needed
                
                    exit();
                } else {
                echo 'File not found';
             }
            } 
            else {
                echo 'Database error';
            }
            
        }
        
        //IF EXTENDED EI
        if($master_type == "ei" && $file_type == "extended"){
             $stmt = $pdo->prepare("
            SELECT files.file_name, files.file_data, ei.ei_tenure_start_date, ei.ei_extended_date
            FROM files
            LEFT JOIN ei ON files.unique_id = ei.ei_unique_id
            WHERE files.file_type = :file_type AND files.unique_id = :unique_id
            ORDER BY files.created_at DESC
            LIMIT 1;
        ");

            $stmt->bindParam(':file_type', $file_type);
            $stmt->bindParam(':unique_id', $unique_id);

            if ($stmt->execute()) {
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($result) {
                // Set the appropriate content type as JPEG
                header("Content-Type: image/jpeg");
                
               $filenameWithoutExtension = pathinfo($result['file_name'], PATHINFO_FILENAME);

                // Construct the filename with extracted filename, ei_tenure_start_date_to_ei_tenure_end_date, and always use .jpg extension
                $filename = $filenameWithoutExtension . '_' . $result['ei_tenure_start_date'] . '_to_' . $result['ei_extended_date'] . '.jpg';
            
                // Set the Content-Disposition header with only the filename
                header("Content-Disposition: attachment; filename=\"$filename\"");
                
                // Output the file data
                echo $result['file_data'];
                
                // You can also access ei_tenure_start_date and ei_tenure_end_date from $result array if needed
                exit();
                } else {
                echo 'File not found';
            }
            } 
            else {
                echo 'Database error';
            }
        }
        
        //IF MASTER TYPE IS EI
        elseif($master_type == "ei"){
             $stmt = $pdo->prepare("
            SELECT files.file_name, files.file_data, ei.ei_tenure_start_date, ei.ei_tenure_end_date
            FROM files
            LEFT JOIN ei ON files.unique_id = ei.ei_unique_id
            WHERE files.file_type = :file_type AND files.unique_id = :unique_id
            ORDER BY files.created_at DESC
            LIMIT 1;
        ");

            $stmt->bindParam(':file_type', $file_type);
            $stmt->bindParam(':unique_id', $unique_id);

            if ($stmt->execute()) {
            $result = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($result) {
                // Set the appropriate content type as JPEG
                header("Content-Type: image/jpeg");
                
               $filenameWithoutExtension = pathinfo($result['file_name'], PATHINFO_FILENAME);

                // Construct the filename with extracted filename, ei_tenure_start_date_to_ei_tenure_end_date, and always use .jpg extension
                $filename = $filenameWithoutExtension . '_' . $result['ei_tenure_start_date'] . '_to_' . $result['ei_tenure_end_date'] . '.jpg';
            
                // Set the Content-Disposition header with only the filename
                header("Content-Disposition: attachment; filename=\"$filename\"");
                
                // Output the file data
                echo $result['file_data'];
                
                // You can also access ei_tenure_start_date and ei_tenure_end_date from $result array if needed
                exit();
                } else {
                echo 'File not found';
            }
            } 
            else {
                echo 'Database error';
            }
        }
        
        
    }
} catch (PDOException $e) {
    echo 'Database error: ' . $e->getMessage();
}

?>