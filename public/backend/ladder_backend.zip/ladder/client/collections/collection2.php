<?php

require_once('response.php');
require_once('db.php');


try {
    $conn = connectToDatabase();

    // Get JSON data from the request body
    $json_data = file_get_contents('php://input');
    $data = json_decode($json_data, true);
    
    echo $data;

    // Initialize variables for date and company_id filtration
    $start_date = null;
    $end_date = null;
    $company_id = null;

    $daysFilter = isset($data['days']) ? $data['days'] : null;
    $projectFilter = isset($data['project_id']) ? $data['project_id'] : null;
    $developerFilter = isset($data['developer_id']) ? $data['developer_id'] : null;
    $branchFilter = isset($data['branch_id']) ? $data['branch_id'] : null;
    $companyFilter = isset($data['company_id']) ? $data['company_id'] : null;

    $filterArrayData = [];

    if (isset($data['start_date'])) {
        $start_date = $data['start_date'];
    }
    
    if (isset($data['end_date'])) {
        $end_date = $data['end_date'];
    }
    
    //Filter By Project
    if($projectFilter !== null){
        $getByProject = "SELECT company_id FROM project WHERE project_id IN ($projectFilter)";
        $getByProjectResult = $conn->query($getByProject);
    
       if ($getByProjectResult) {
           while ($row = $getByProjectResult->fetch_assoc()) {
                    $filterArrayData[] = $row['company_id'];
           }
           
       } else {
        $response = new Response();
        $response->setHttpStatusCode(200);
        $response->setSuccess(true);
        $response->addMessage("Cannot found company");
        $response->setData($data);
        $response->send();
        exit;
         }
    }
    
    //Filter By Developer
    if($developerFilter !== null){
        $getByDeveloper = "SELECT company_id FROM company WHERE developer_id IN ($developerFilter)";
        $getByDeveloperResult = $conn->query($getByDeveloper);
    
       if ($getByDeveloperResult) {
           while ($row = $getByDeveloperResult->fetch_assoc()) {
                    $filterArrayData[] = $row['company_id'];
           }
           
       } else {
        $response = new Response();
        $response->setHttpStatusCode(200);
        $response->setSuccess(true);
        $response->addMessage("Cannot found company");
        $response->setData($data);
        $response->send();
        exit;
         }
    }
    
    if($branchFilter !== null){
        $getByBranchFilter = "SELECT DISTINCT c.company_id
        FROM company c
        JOIN developer d ON c.developer_id = d.developer_id
        WHERE d.location_id IN ($branchFilter);";
        $getByBranchResult = $conn->query($getByBranchFilter);
    
       if ($getByBranchResult) {
           while ($row = $getByBranchResult->fetch_assoc()) {
                    $filterArrayData[] = $row['company_id'];
           }
           
       } else {
        $response = new Response();
        $response->setHttpStatusCode(200);
        $response->setSuccess(true);
        $response->addMessage("Cannot found branch");
        $response->setData($data);
        $response->send();
        exit;
         }
    }
    
    if($companyFilter !== null){
        $getByCompanyFilter = "SELECT DISTINCT company_id
        FROM company 
        WHERE company_id IN ($companyFilter);";
        $getByCompanyResult = $conn->query($getByCompanyFilter);
    
       if ($getByCompanyResult) {
           while ($row = $getByCompanyResult->fetch_assoc()) {
                    $filterArrayData[] = $row['company_id'];
           }
           
       } else {
        $response = new Response();
        $response->setHttpStatusCode(200);
        $response->setSuccess(true);
        $response->addMessage("Cannot found company");
        $response->setData($data);
        $response->send();
        exit;         
      }
    }
    
    $filterArrayDataUnique = null;
    
    if ($filterArrayData !== null){
        $filterArrayDataUnique = implode(',', array_unique($filterArrayData));
    }

    // SQL query with date and company_id filtration
    $sql = "
        SELECT
            i.invoice_number,
            i.invoice_raise_date,
            i.submit_date,
            bd.closure_date,
            osr.completed AS sdr_date
        FROM
            booking_details bd
            LEFT JOIN invoice i ON bd.client_id = i.client_id
            LEFT JOIN ob_status_records osr ON bd.booking_id = osr.booking_id
        WHERE
            osr.status_id = 3 AND osr.completed IS NOT NULL";

    // Add date filtration if both start_date and end_date are provided
    if ($start_date !== null && $end_date !== null) {
        $sql .= " AND osr.completed BETWEEN '$start_date' AND '$end_date'";
    }

    // Add company_id filtration if provided
    if (!empty($filterArrayData)) {
        $filterArrayDataUnique = implode(',', array_unique($filterArrayData));
        $sql .= " AND i.company_id IN ($filterArrayDataUnique)";
    }

    if ($daysFilter !== null) {
        $sql .= " AND DATEDIFF(i.submit_date, i.invoice_raise_date) = $daysFilter";
    }

    $sql .= ";";

    $result = $conn->query($sql);

    if (!$result) {
        throw new Exception("Query failed: " . $conn->error);
    }

    $data = [];

    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    if (empty($data)) {
        $response = new Response();
        $response->setHttpStatusCode(200);
        $response->setSuccess(true);
        $response->addMessage("No results found");
        $response->setData($data);
        $response->send();
        exit;
    } else {
        $response = new Response();
        $response->setHttpStatusCode(200);
        $response->setSuccess(true);
        $response->addMessage("Got results");
        $response->setData($data);
        $response->send();
        exit;
    }
} catch (Exception $ex) {
    // Handle exceptions
    error_log("Error: " . $ex->getMessage(), 0);
    $response = new Response();
    $response->setHttpStatusCode(500);
    $response->setSuccess(false);
    $response->addMessage("An error occurred");
    $response->send();
} finally {
    // Close connection
    if (isset($conn)) {
        $conn->close();
    }
}
?>
