<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once('response.php');
require_once('db.php');

function handleErrorResponse($message, $statusCode = 500) {
    $response = new Response();
    $response->setHttpStatusCode($statusCode);
    $response->setSuccess(false);
    $response->addMessage($message);
    $response->send();
    exit;
}

function getCompanyIdsByFilter($conn, $query) {
    $result = $conn->query($query);
    if ($result) {
        return $result->fetch_all(MYSQLI_ASSOC);
    } else {
        handleErrorResponse('Query execution failed');
    }
}

function isValidDateFormat($dateString) {
    return strtotime($dateString) !== false;
}

try {
    $conn = connectToDatabase();

    $rawPatchdata = file_get_contents('php://input');
    $data = json_decode($rawPatchdata, true);
    

    // Extract filters from $data
    $projectFilter = $data['project_id'] ?? null;
    $developerFilter = $data['developer_id'] ?? null;
    $branchFilter = $data['branch_id'] ?? null;
    $companyFilter = $data['company_id'] ?? null;

    $filterArrayData = [];

    // Filter By Project
    if ($projectFilter !== null && !empty($projectFilter)) {
        $query = "SELECT company_id FROM project WHERE project_id IN ($projectFilter)";
        $filterArrayData = array_merge($filterArrayData, getCompanyIdsByFilter($conn, $query));
    }

    // Filter By Developer
    if ($developerFilter !== null && !empty($developerFilter)) {
        $query = "SELECT company_id FROM company WHERE developer_id IN ($developerFilter)";
        $filterArrayData = array_merge($filterArrayData, getCompanyIdsByFilter($conn, $query));
    }

    // Filter By Branch
    if ($branchFilter !== null && !empty($branchFilter)) {
        $query = "SELECT DISTINCT c.company_id FROM company c JOIN developer d ON c.developer_id = d.developer_id WHERE d.location_id IN ($branchFilter)";
        $filterArrayData = array_merge($filterArrayData, getCompanyIdsByFilter($conn, $query));
    }

    // Filter By Company
    if ($companyFilter !== null && !empty($companyFilter)) {
        $query = "SELECT DISTINCT company_id FROM company WHERE company_id IN ($companyFilter)";
        $filterArrayData = array_merge($filterArrayData, getCompanyIdsByFilter($conn, $query));
    }

    if (!empty($filterArrayData)) {
       // echo(json_encode($filterArrayData));
        $companyIds = array_column($filterArrayData, 'company_id');
        $filterArrayDataUnique = implode(',', array_unique($companyIds));
    }

    if (!empty($rawPatchdata)) {
        $jsonData = json_decode($rawPatchdata);
        if (!$jsonData) {
            handleErrorResponse("Request body is not valid JSON", 400);
        }
    } else {
        $jsonData = new stdClass();
    }

    $sql = "SELECT
    SUM(
        CASE WHEN i.raise_status_id = 1 THEN i.invoice_value
    END
    ) AS net_revenue,
    COUNT(
    CASE WHEN i.raise_status_id = 1 THEN bd.client_id
    END
    ) AS total_invoice_raised,
    COUNT(
    CASE WHEN i.raise_status_id = 1 AND i.post_raise_id = 1 THEN bd.client_id
    END
    ) AS total_invoice_pending,
    COUNT(
    CASE WHEN i.post_raise_id = 2 AND i.expected_receive_date IS NULL THEN bd.client_id
    END
    ) AS total_outstanding,
    COUNT(
    CASE WHEN i.post_raise_id = 3 THEN bd.client_id
    END
    ) AS total_invoice_received,
    COUNT(
    CASE WHEN  i.post_raise_id = 4 THEN bd.client_id
    END
    ) AS total_can,
    SUM(bd.agreement_value) AS total_agreement_value,
    COUNT(bd.booking_id) AS total_booking,
    ROUND(
    AVG(
        bd.base_brokerage + COALESCE(bd.ladder_stage, 0)
    ),
    2
    ) AS average_brokerage,
    SUM(
    CASE WHEN i.post_raise_id = 3 THEN bd.agreement_value ELSE 0
    END
    ) AS net_revenue,
    SUM(
    bd.agreement_value * bd.base_brokerage +(
        (
            bd.agreement_value * bd.base_brokerage
        ) * 18 / 100
    ) -(
        (
            bd.agreement_value * bd.base_brokerage
        ) * 5 / 100
    ) - COALESCE(bd.cashback_amount, 0)
    ) AS total_gross_amount,
    SUM(
    COALESCE(bd.cashback_amount, 0)
    ) AS total_cashback_amount
    FROM
    booking_details AS bd
    JOIN invoice i ON
    bd.client_id = i.client_id";

    if (!empty($filterArrayDataUnique)) {
        $sql .= " AND i.company_id IN ($filterArrayDataUnique)";
    }
    

    if (isset($data['start_date'], $data['end_date'])) {
        $start_date = $data['start_date'];
        $end_date = $data['end_date'];

        if (isValidDateFormat($start_date) && isValidDateFormat($end_date)) {
            $sql .= " WHERE bd.closure_date BETWEEN :start_date AND :end_date";
        } else {
            handleErrorResponse("Incorrect date format. Both start_date and end_date should be valid dates.", 400);
        }
    }

    $sql .= ";";

    try {
        $stmt = $conn->prepare($sql);

        if (isset($start_date, $end_date)) {
            // Update the bind_param based on the actual data types of $start_date and $end_date
            $stmt->bind_param('ss', $start_date, $end_date);
        }

        $stmt->execute();
        $result = $stmt->get_result();
        $data2 = $result->fetch_all(MYSQLI_ASSOC);

        if (!empty($data2) && $data2[0]["total_booking"] === "0") {
            handleErrorResponse("Results are empty. Please check the dates that you have passed.", 400);
        } else {
            $response = new Response();
            $response->setHttpStatusCode(200);
            $response->setSuccess(true);
            $response->addMessage("Got results");
            $response->setData($data2);
            $response->send();
        }
    } catch (PDOException $ex) {
        error_log("Error: " . $ex->getMessage(), 0);
        handleErrorResponse("An error occurred", 500);
    }

} catch (PDOException $ex) {
    error_log("Error: " . $ex->getMessage(), 0);
    handleErrorResponse("An error occurred");
}

?>
