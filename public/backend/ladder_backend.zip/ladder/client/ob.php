<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'database.php';


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}



// Function to handle JSON response
function jsonResponse($statusCode, $data) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
}

// Get the JSON data from the request body
$json_data = file_get_contents('php://input');

// Decode the JSON data into an associative array
$data = json_decode($json_data, true);

// Check if data are set
if (isset($data['booking_id'])) {
    $booking_id = $data['booking_id'];
}

if (isset($data['status_id'])) {
    $status_id = $data['status_id'];
}

if (isset($data['expected_date'])) {
    $expected_date = $data['expected_date'];
}

if (isset($data['completed_date'])) {
    $completed_date = $data['completed_date'];
}



if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $formattedDate = date('Y-m-d', strtotime($completed_date));

    $checkSql = "SELECT COUNT(*) as count FROM `ob_status_records` WHERE `status_id` < ? AND completed != null";
    $checkStmt = $conn->prepare($checkSql);
    $checkStmt->bind_param('i', $status_id);
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    $row = $result->fetch_assoc();
    $count = $row['count'];

    if ($count > 0) {
        $insertSql = "INSERT INTO `ob_status_records` (`booking_id`, `status_id`, `completed`) VALUES (?, ?, ?)";

        $insertStmt = $conn->prepare($insertSql);

        $insertStmt->bind_param('iis', $booking_id, $status_id, $formattedDate);

        if ($insertStmt->execute()) {
            $insertStmt->close();
            $conn->close();
            jsonResponse(200, ['message' => 'Data inserted successfully.']);
        } else {
            $error = [
                'error' => 'Data insertion failed',
                'sql_error' => $insertStmt->error, 
            ];
            $insertStmt->close();
            $conn->close();
            jsonResponse(500, $error);
        }
    } else {
        $conn->close();
        jsonResponse(400, ['error' => 'The previous OB stage was not completed']);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'PATCH') {
    // Establish a database connection
    $conn = connectToDatabase();

    // Validate and format the expected date
    $formattedDate2 = date('Y-m-d', strtotime($completed_date));

    // Define the SQL query for updating data
    $sql = "UPDATE `ob_status_records`
    SET
        `status_id` = GREATEST(`status_id`, ?),";

    // Check the value of $status_id and update the corresponding column
    switch ($status_id) {
        case 2:
            $sql .= "`ba2_date` = ?";
            break;
        case 3:
            $sql .= "`sdr_date` = ?";
            break;
        case 4:
            $sql .= "`composite_date` = ?";
            break;
        case 5:
            $sql .= "`ba_4` = ?";
            break;
        default:
            break;
    }

    $sql .= " WHERE
        `booking_id` = ?";

    // Prepare the SQL statement
    $stmt = $conn->prepare($sql);

    // Bind the parameters using bind_param
    if ($status_id >= 2 && $status_id <= 5) {
        $stmt->bind_param('iss', $status_id, $formattedDate2, $booking_id);
    } else {
        $stmt->bind_param('ii', $status_id, $booking_id);
    }

    // Execute the SQL statement
    if ($stmt->execute()) {
        $stmt->close();
        $conn->close();
        jsonResponse(200, ['message' => 'Data Updated successfully.']);
    } else {
        // Capture and display the SQL error
        $error = [
            'error' => 'Data updation failed',
            'sql_error' => $stmt->error, // Get the SQL error message
        ];
        $stmt->close();
        $conn->close();
        jsonResponse(500, $error);
    }
}





?>
