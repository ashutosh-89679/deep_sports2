<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once('db.php');
require_once('response.php');

function isValidDateFormat($dateString) {
    $pattern = '/^\d{4}-\d{2}-\d{2}$/';
    return preg_match($pattern, $dateString) === 1;
}

try {
    $conn = connectToDatabase();
} catch (PDOException $ex) {
    // log connection error for troubleshooting and return a json error response
    error_log("Connection Error: " . $ex, 0);
    $response = new Response();
    $response->setHttpStatusCode(500);
    $response->setSuccess(false);
    $response->addMessage("Database connection error");
    $response->send();
    exit;
}

$rawPatchdata = file_get_contents('php://input');
$data = json_decode($rawPatchdata, true);
$start_date = null;
$end_date = null;

if (!empty($rawPatchdata)) {
    $jsonData = json_decode($rawPatchdata);
    if (!$jsonData) {
        // set up response for unsuccessful request
        $response = new Response();
        $response->setHttpStatusCode(400);
        $response->setSuccess(false);
        $response->addMessage("Request body is not valid JSON");
        $response->send();
        exit;
    }
} else {
    // If JSON data is not provided, create an empty object
    $jsonData = new stdClass();
}

$sql = "SELECT
        SUM(bd.agreement_value) AS total_agreement_value,
        COUNT(bd.booking_id) AS total_booking,
        ROUND(AVG(bd.base_brokerage + COALESCE(bd.ladder_stage, 0)),2) AS average_brokerage,
        SUM(CASE WHEN i.post_raise_id = 3 THEN bd.agreement_value ELSE 0 END) AS net_revenue,
        SUM(
            bd.agreement_value * bd.base_brokerage +(
                (
                    bd.agreement_value * bd.base_brokerage
                ) * 18 / 100
            ) -(
                (
                    bd.agreement_value * bd.base_brokerage
                ) * 5 / 100
            ) - COALESCE(bd.cashback_amount, 0)
        ) AS total_gross_amount,
        SUM(
            COALESCE(bd.cashback_amount, 0)
        ) AS total_cashback_amount
    FROM
        booking_details AS bd
        JOIN invoice i ON bd.client_id = i.client_id";



if (isset($data['start_date'])) {
    $start_date = $data['start_date'];
}

if (isset($data['end_date'])) {
    $end_date = $data['end_date'];
}


if ($start_date && $end_date) {
    if (isValidDateFormat($start_date) && isValidDateFormat($end_date)) {
        $sql .= " WHERE bd.closure_date BETWEEN '$start_date' AND '$end_date'";
    } else {
        $response = new Response();
        $response->setHttpStatusCode(400);
        $response->setSuccess(false);
        $response->addMessage("Incorrect date format. Both start_date and end_date should be in the format YYYY-MM-DD.");
        $response->send();
        exit;
    }
}


try {
    $result = $conn->query($sql);
    //echo $sql;

    if (!$result) {
        $response = new Response();
        $response->setHttpStatusCode(400);
        $response->setSuccess(false);
        $response->addMessage("Cannot fetch data Or incorrect date");
        $response->send();
        exit;
    }

    // Fetch the data from the result set
     $data2 = $result->fetch_all(MYSQLI_ASSOC);

     //echo json_encode($data2);
     
     if (!empty($data2) && $data2[0]["total_booking"] === "0") {
        // Query executed successfully, but results are all zero
        $response = new Response();
        $response->setHttpStatusCode(400);
        $response->setSuccess(true);
        $response->addMessage("Results are  empty please try checking the dates that you have passed");
        $response->send();
        exit;
    }else{
        $response = new Response();
        $response->setHttpStatusCode(200);
        $response->setSuccess(true);
        $response->addMessage("Got results");
        $response->setData($data2);
        $response->send();
    }
    
    


} catch (Exception $ex) {
    // Handle exceptions
    error_log("Error: " . $ex->getMessage(), 0);
    $response = new Response();
    $response->setHttpStatusCode(500);
    $response->setSuccess(false);
    $response->addMessage("An error occurred");
    $response->send();
    exit;
}

?>
