<?php
// Database configuration (update with your database credentials)
include 'ladderDb.php';


error_reporting(E_ALL);
ini_set('display_errors', 1);


// Initialize variables for headers
$locationId = null;
$developerId = null;

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");


if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}

// Check if developer_id header is set
$headers = getallheaders();

// Check if project_id header is set
if (isset($headers['Http_project_id'])) {
    $projectIds = explode(',', $headers['Http_project_id']);
}

if (isset($headers['Http_start_date'])) {
    $ladderStartDate = $headers['Http_start_date'];
}

if (isset($headers['Http_end_date'])) {
    $ladderEndDate = $headers['Http_end_date'];
}

if (isset($headers['Http_ladder_type'])) {
    $ladderType = $headers['Http_ladder_type'];
}


// Convert the headers to a JSON string
$headersJson = json_encode($headers, JSON_PRETTY_PRINT);

// Define the file path where you want to save the headers
$filePath = 'check.txt';

// Append the headers to the file

try {
    // Connect to the database
    $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    function generateUniqueLadderId() {
        $uniqueId = 'ladder_' . time();
        return $uniqueId;
    }
    

    $uniqueId = generateUniqueLadderId();

    // Check if the HTTP request method is POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') { 
        // Get the JSON data from the request body
        $json_data = file_get_contents("php://input");
        $data = json_decode($json_data, true);
        file_put_contents($filePath, $headersJson . PHP_EOL, FILE_APPEND);


        if (is_array($data)) {
            foreach ($data as $stageKey => $stageData) {
                // Process each stage's data
                if (is_array($stageData)) {
                    $min_unit = $stageData['minValue'];
                    $max_unit = $stageData['maxValue'];
                    $percent = $stageData['percentValue'];

                        $stmt = $pdo->prepare("INSERT INTO ladder ( ladder_stage, ladder_stage_start, ladder_stage_end, stage_percent, ladder_start_date, ladder_end_date, ladder_type , ladder_id) 
                                            VALUES (:ladder_stage, :ladder_stage_start, :ladder_stage_end, :stage_percent, :ladder_start_date, :ladder_end_date , :ladder_type , :ladder_id)");
                        $stmt->bindParam(':ladder_stage', $stageKey);
                        $stmt->bindParam(':ladder_stage_start', $min_unit);
                        $stmt->bindParam(':ladder_stage_end', $max_unit);
                        $stmt->bindParam(':stage_percent', $percent);
                        $stmt->bindParam(':ladder_start_date', $ladderStartDate);
                        $stmt->bindParam(':ladder_end_date', $ladderEndDate);
                        $stmt->bindParam(':ladder_type', $ladderType);
                        $stmt->bindParam(':ladder_id', $uniqueId);
                        $stmt->execute();
                    
                }
            }

            foreach ($projectIds as $projectId) {
                $stmt = $pdo->prepare("INSERT INTO project_ladder ( project_id , ladder_id) 
                VALUES (:project_id , :ladder_id)");
                $stmt->bindParam(':project_id', $projectId);
                $stmt->bindParam(':ladder_id', $uniqueId);
                $stmt->execute();
            }
            // Return a JSON response for success
           $response = ['message' => 'Data received and processed successfully', 'uniqueId' => $uniqueId];
            header('HTTP/1.1 200 OK');
            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $response = ['error' => 'Invalid JSON data'];
            header('HTTP/1.1 400 Bad Request');
            header('Content-Type: application/json');
            echo json_encode($response);
        }
    } else {
        $response = ['error' => 'Invalid request method'];
        header('HTTP/1.1 405 Method Not Allowed');
        header('Content-Type: application/json');
        echo json_encode($response);
    }
} catch (PDOException $e) {
    $response = ['error' => 'Database error: ' . $e->getMessage()];
    header('HTTP/1.1 500 Internal Server Error');
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
