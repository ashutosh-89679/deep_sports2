<?php

include 'database.php';


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$json_data = file_get_contents('php://input');
$data = json_decode($json_data, true);

function separateDates($dateRange) {
    $dates = explode(" - ", $dateRange);
    if (count($dates) === 2) {
        list($startDate, $endDate) = $dates;
        return array('start_date' => $startDate, 'end_date' => $endDate);
    } else {
        return null; 
    }
}


if(isset($data)){
    file_put_contents('headerx.txt' , $json_data);
}

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type");

if (isset($_SERVER['HTTP_ORIGIN'])) {
    header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
    header('Access-Control-Allow-Credentials: true');
    header('Access-Control-Max-Age: 86400');    // cache for 1 day
}
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
        header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS, PATCH");
    if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
        header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
    exit();
}


$projectIDS = null;
$configurations = null;
$sourced_by = null;
$closed_by = null;
$closure_date = null;
$ba2Date = null;
$ba3Date = null;
$sdrDate = null;
$invoice_status = null;
$invoice_post_raise_status = null;
$deal_status = null;
$max_av = False;
$recent_closure = False;

$bookingIDSarray = [];


if (isset($data['name_number'])) {
    $nameNumber = $data['name_number'];
if (!empty($nameNumber)){
    $sql = "SELECT User_id FROM booked_clients WHERE name LIKE '%$nameNumber%' OR number LIKE '%$nameNumber%'";
    $result = $conn->query($sql);

    if ($result) {
        $userIds = [];
        while ($row = $result->fetch_assoc()) {
            $userIds[] = $row['User_id'];
        }
        if (!empty($userIds)) {
            $userIdsStr = implode(',', $userIds);

            $bookingSql = "SELECT booking_id FROM booking_details WHERE client_id IN ($userIdsStr)";
            $bookingResult = $conn->query($bookingSql);

            if ($bookingResult) {
                while ($bookingRow = $bookingResult->fetch_assoc()) {
                    $bookingIDSarray[] = $bookingRow['booking_id'];
                }
            } else {
                echo json_encode(['error' => 'Booking details query execution failed']);
            }
        }
    } 
}
}

if (isset($data['project_ids'])) {
   $projectIDS = $data['project_ids'];
    if (!empty($projectIDS)){
        

   $sql2 = "SELECT booking_id FROM booking_details WHERE project_id IN ($projectIDS)";
   $result2 = $conn->query($sql2);
   

   if ($result2) {
       $userIds = [];
       while ($row = $result2->fetch_assoc()) {
                $bookingIDSarray[] = $row['booking_id'];
       }
       
   } else {
       echo json_encode(['error' => 'Query execution failed']);
     }
   
   }
}

if (isset($data['configurations'])) {
   $configurations = $data['configurations'];
   if (!empty($configurations) || $configurations !== ""){

   $sql3 = "SELECT booking_id FROM booking_details WHERE configuration_id IN ($configurations)";
   $result3 = $conn->query($sql3);

   if ($result3) {
       while ($row = $result3->fetch_assoc()) {
                $bookingIDSarray[] = $row['booking_id'];
       }
       
   } else {
       echo json_encode(['error' => 'Query execution failed']);
      }
   }
  
}

if (isset($data['sourced_by'])) {
   $sourced_by  = $data['sourced_by'];
   if (!empty($sourced_by)){

   $sql4 = "SELECT booking_id FROM booking_details WHERE sourced_by  IN ($sourced_by)";
   $result4 = $conn->query($sql4);

   if ($result4) {
       while ($row = $result4->fetch_assoc()) {
                $bookingIDSarray[] = $row['booking_id'];
       }
       
   } else {
       echo json_encode(['error' => 'Query execution failed']);
   }
   }
}

if (isset($data['closed_by'])) {
    $closed_by  = $data['closed_by'];
    
    if (!empty($closed_by)){

   $sqlc = "SELECT booking_id FROM booking_details WHERE closed_by  IN ($closed_by)";
   $resultc = $conn->query($sqlc);

   if ($resultc) {
       while ($row = $resultc->fetch_assoc()) {
                $bookingIDSarray[] = $row['booking_id'];
       }
       
   } else {
       echo json_encode(['error' => 'Query execution failed']);
   }
   }
}

if (isset($data['followup_date'])){
    $followupDate = $data['followup_date'];
    if(!empty($followupDate) || $followupDate !== "" || $followupDate !== null){
        $followupDateArray = separateDates($followupDate);
        $fStartDate = $followupDateArray['start_date'];
        $fEndDate = $followupDateArray['end_date'];
        if($fStartDate !== $fEndDate){
            $followSql = "SELECT booking_id FROM followups WHERE followup_date BETWEEN '$fStartDate' AND '$fEndDate' ";
            $followResult = $conn->query($followSql);
            
            if($followResult){
                 while ($row = $followResult->fetch_assoc()) {
                             $bookingIDSarray[] = $row['booking_id'];
                    }
            }
        }
        else if ($fStartDate == $fEndDate){
            $followSql = "SELECT booking_id FROM followups WHERE followup_date = '$fStartDate'";
            $followResult = $conn->query($followSql);
            
            if($followResult){
                 while ($row = $followResult->fetch_assoc()) {
                             $bookingIDSarray[] = $row['booking_id'];
                    }
            }
        }
    }
}

if(isset($data['agreement_range'])){
    $agreement_range = $data['agreement_range'];
    if(!empty($agreement_range) || $agreement_range !== "" || $agreement_range !== null){
        list($min, $max) = explode(' - ', $agreement_range);
        $min = intval($min);
        $max = intval($max);
        $agreementSql = "SELECT booking_id FROM booking_details WHERE agreement_value BETWEEN '$min' AND '$max' ";
        $agreementResult = $conn->query($agreementSql);
        
        if($agreementResult){
           while ($row = $agreementResult->fetch_assoc()) {
                             $bookingIDSarray[] = $row['booking_id'];
                    } 
        }

    }
    
}

if (isset($data['closure_date'])) {
    $closure_date = $data['closure_date'];
     if (!empty($closure_date) || $closure_date !== "" || $closure_date !== null){
    $closureDateArray = separateDates($closure_date);
    if($closureDateArray !== null){
        $closure_start_date = $closureDateArray['start_date'];
        $closure_end_date = $closureDateArray['end_date'];
        if($closure_start_date !== $closure_end_date){
            $sql5 = "SELECT booking_id FROM booking_details WHERE closure_date  BETWEEN '$closure_start_date' AND '$closure_end_date' ";
                $result5 = $conn->query($sql5);
            
                if ($result5) {
                    while ($row = $result5->fetch_assoc()) {
                             $bookingIDSarray[] = $row['booking_id'];
                    }
                    
                } else {
                    echo json_encode(['error' => 'Query execution failed']);
                }
        } elseif ($closure_start_date === $closure_end_date){
            $sql6 = "SELECT booking_id FROM booking_details WHERE closure_date  = '$closure_start_date'";
                $result6 = $conn->query($sql6);
            
                if ($result6) {
                    while ($row = $result6->fetch_assoc()) {
                             $bookingIDSarray[] = $row['booking_id'];
                    }
                    
                } else {
                    echo json_encode(['error' => 'Query execution failed']);
                }
        }
    }
}
}

if (isset($data['ba1_date'])) {
    $ba1Date = $data['ba1_date'];
      if($ba1Date !== null || $ba1Date !== ""){
    $ba1DateArray = separateDates($ba1Date);
    if($ba1DateArray !== null){
        $ba1StartDate = $ba1DateArray['start_date'];
        $ba1EndDate = $ba1DateArray['end_date'];
        if($ba1StartDate !== $ba1EndDate){
            $sql7 = "SELECT bd.booking_id
            FROM booking_details bd
            WHERE bd.os_status_id IN (
                SELECT osr.ob_record_id
                FROM ob_status_records osr
                WHERE osr.status_id = 1 AND bd.closure_date  BETWEEN '$ba1StartDate' AND '$ba1EndDate')";
            $result7 = $conn->query($sql7);
        
            if ($result7) {
                while ($row = $result7->fetch_assoc()) {
                         $bookingIDSarray[] = $row['booking_id'];
                }
                
            } else {
                echo json_encode(['error' => 'Query execution failed']);
            }
        }elseif ($ba1StartDate === $ba1EndDate){
            $sql8 = "SELECT bd.booking_id
            FROM booking_details bd
            WHERE bd.os_status_id IN (
                SELECT osr.ob_record_id
                FROM ob_status_records osr
                WHERE osr.status_id = 1 AND bd.closure_date = '$ba1StartDate')";
            $result8 = $conn->query($sql8);
        
            if ($result8) {
                while ($row = $result8->fetch_assoc()) {
                         $bookingIDSarray[] = $row['booking_id'];
                }
                
            } else {
                echo json_encode(['error' => 'Query execution failed']);
            }
        }
    }
  }
}

if (isset($data['ba2_date'])) {
    $ba2Date = $data['ba2_date'];
      if($ba2Date !== null || $ba2Date !== ""){
    $ba2DateArray = separateDates($ba2Date);
    if($ba2DateArray !== null){
        $ba2StartDate = $ba2DateArray['start_date'];
        $ba2EndDate = $ba2DateArray['end_date'];
        if($ba2StartDate !== $ba2EndDate){
            $sql7 = "SELECT bd.booking_id
            FROM booking_details bd
            WHERE bd.os_status_id IN (
                SELECT osr.ob_record_id
                FROM ob_status_records osr
                WHERE osr.ba2_date BETWEEN '$ba2StartDate' AND '$ba2EndDate' AND status_id = 2
            );";
            $result7 = $conn->query($sql7);
        
            if ($result7) {
                while ($row = $result7->fetch_assoc()) {
                         $bookingIDSarray[] = $row['booking_id'];
                }
                
            } else {
                echo json_encode(['error' => 'Query execution failed']);
            }
        }elseif ($ba2StartDate === $ba2EndDate){
            $sql8 = "SELECT bd.booking_id
            FROM booking_details bd
            WHERE bd.os_status_id IN (
                SELECT osr.ob_record_id
                FROM ob_status_records osr
                WHERE osr.ba2_date = '$ba2StartDate' AND status_id = 2)";
            $result8 = $conn->query($sql8);
        
            if ($result8) {
                while ($row = $result8->fetch_assoc()) {
                         $bookingIDSarray[] = $row['booking_id'];
                }
                
            } else {
                echo json_encode(['error' => 'Query execution failed']);
            }
        }
    }
  }
}

if (isset($data['sdr_date'])) {
    $sdrDate = $data['sdr_date'];
    if($sdrDate !== null || $sdrDate !== ""){
    $sdrDateArray = separateDates($sdrDate);
    if($sdrDateArray !== null){
        $sdrStartDate = $sdrDateArray['start_date'];
        $sdrEndDate = $sdrDateArray['end_date'];
        if($sdrStartDate !== $sdrEndDate){
            $sql9 = "SELECT bd.booking_id
            FROM booking_details bd
            WHERE bd.os_status_id IN (
                SELECT osr.ob_record_id
                FROM ob_status_records osr
                WHERE osr.sdr_date BETWEEN '$sdrStartDate' AND '$sdrEndDate' AND status_id = 3)";
            $result9 = $conn->query($sql9);
        
            if ($result9) {
                while ($row = $result9->fetch_assoc()) {
                         $bookingIDSarray[] = $row['booking_id'];
                }
                
            } else {
                echo json_encode(['error' => 'Query execution failed']);
            }
        }elseif ($sdrStartDate === $sdrEndDate){
            $sql10 = "SELECT bd.booking_id
            FROM booking_details bd
            WHERE bd.os_status_id IN (
                SELECT osr.ob_record_id
                FROM ob_status_records osr
                WHERE osr.sdr_date = '$sdrStartDate' AND status_id = 3)";
            $result10 = $conn->query($sql10);
        
            if ($result10) {
                while ($row = $result10->fetch_assoc()) {
                         $bookingIDSarray[] = $row['booking_id'];
                }
                
            } else {
                echo json_encode(['error' => 'Query execution failed']);
            }
        }
    }
    
}
    
}

if (isset($data['composite_payment'])) {
    $composite_payment = $data['composite_payment'];
    if($composite_payment !== null || $composite_payment !== ""){
    $composite_paymentDateArray = separateDates($composite_payment);
    if($composite_paymentDateArray !== null){
        $compositeStartDate = $composite_paymentDateArray['start_date'];
        $compositeEndDate = $composite_paymentDateArray['end_date'];
        if($compositeStartDate !== $compositeEndDate){
            $sql9 = "SELECT bd.booking_id
            FROM booking_details bd
            WHERE bd.os_status_id IN (
                SELECT osr.ob_record_id
                FROM ob_status_records osr
                WHERE osr.composite_date BETWEEN '$compositeStartDate' AND '$compositeEndDate' AND status_id = 4)";
            $result9 = $conn->query($sql9);
        
            if ($result9) {
                while ($row = $result9->fetch_assoc()) {
                         $bookingIDSarray[] = $row['booking_id'];
                }
                
            } else {
                echo json_encode(['error' => 'Query execution failed']);
            }
        }elseif ($compositeStartDate === $compositeEndDate){
            $sql10 = "SELECT bd.booking_id
            FROM booking_details bd
            WHERE bd.os_status_id IN (
                SELECT osr.ob_record_id
                FROM ob_status_records osr
                WHERE osr.composite_date = '$compositeStartDate' AND status_id = 4)";
            $result10 = $conn->query($sql10);
        
            if ($result10) {
                while ($row = $result10->fetch_assoc()) {
                         $bookingIDSarray[] = $row['booking_id'];
                }
                
            } else {
                echo json_encode(['error' => 'Query execution failed']);
            }
        }
    }
    
}
    
}

if (isset($data['ba3_date'])) {
    $ba3Date = $data['ba3_date'];
    if($ba3Date !== null || $ba3Date !== ""){
    $ba3DateArray = separateDates($ba3Date);
    if($ba3DateArray !== null){
        $ba3StartDate = $ba3DateArray['start_date'];
        $ba3EndDate = $ba3DateArray['end_date'];
        if($ba3StartDate !== $ba3EndDate){
            $sql11 = "SELECT bd.booking_id
            FROM booking_details bd
            WHERE bd.os_status_id IN (
                SELECT osr.ob_record_id
                FROM ob_status_records osr
                WHERE  osr.ba_4 BETWEEN '$ba3StartDate' AND '$ba3EndDate' AND status_id = 5)";
            $result11 = $conn->query($sql11);
        
            if ($result11) {
                while ($row = $result11->fetch_assoc()) {
                         $bookingIDSarray[] = $row['booking_id'];
                }
                
            } else {
                echo json_encode(['error' => 'Query execution failed']);
            }
        }elseif ($ba3StartDate === $ba3EndDate){
            $sql12 = "SELECT bd.booking_id
            FROM booking_details bd
            WHERE bd.os_status_id IN (
                SELECT osr.ob_record_id
                FROM ob_status_records osr
                WHERE  osr.ba_4 = '$ba3StartDate' AND status_id = 5
            )";
            $result12 = $conn->query($sql12);
        
            if ($result12) {
                while ($row = $result12->fetch_assoc()) {
                         $bookingIDSarray[] = $row['booking_id'];
                }
                
            } else {
                echo json_encode(['error' => 'Query execution failed']);
            }
        }
    }
    
}
}

if (isset($data['invoice_status'])) {
    $invoice_status = $data['invoice_status'];
    $sql13 = "SELECT bd.booking_id FROM booking_details bd WHERE bd.client_id IN ( SELECT inv.client_id FROM invoice inv WHERE inv.raise_status_id IN ($invoice_status) );";
          $result13 = $conn->query($sql13);
          if ($result13) {
              while ($row = $result13->fetch_assoc()) {
                       $bookingIDSarray[] = $row['booking_id'];
              }
              
          } else {
              echo json_encode(['error' => 'Query execution failed']);
          }
}

if (isset($data['invoice_post_raise_status'])) {
    $invoice_post_raise_status = $data['invoice_post_raise_status'];
    $invoice_post_raise_status = implode(',', array_map('intval', explode(',', $invoice_post_raise_status)));

    $sql14 = "SELECT bd.booking_id 
              FROM booking_details bd 
              WHERE bd.client_id IN (
                  SELECT inv.client_id 
                  FROM invoice inv 
                  WHERE inv.post_raise_id IN ($invoice_post_raise_status)
              );";

    $result14 = $conn->query($sql14);

    if ($result14) {
        while ($row = $result14->fetch_assoc()) {
            $bookingIDSarray[] = $row['booking_id'];
        }
    } else {
        echo json_encode(['error' => 'Query execution failed']);
    }
}

if (isset($data['ba_status'])){
    $ba_status = $data['ba_status'];
    if($ba_status !== null || !empty($ba_status)){
            $sql12 = "SELECT bd.booking_id
            FROM booking_details bd
            WHERE bd.os_status_id IN (
                SELECT osr.ob_record_id
                FROM ob_status_records osr
                WHERE  osr.status_id = $ba_status
            )";
            $result12 = $conn->query($sql12);
        
            if ($result12) {
                while ($row = $result12->fetch_assoc()) {
                         $bookingIDSarray[] = $row['booking_id'];
                }
                
            } else {
                echo json_encode(['error' => 'Query execution failed']);
            }
    }
}

if (isset($data['deal_status'])) {
    $deal_status = $data['deal_status'];
    $sql15 = "SELECT bd.booking_id FROM booking_details bd WHERE bd.client_id IN ( SELECT inv.client_id FROM invoice inv WHERE inv.post_raise_id IN ($invoice_post_raise_status) );";
    $result15 = $conn->query($sql15);
    if ($result15) {
        while ($row = $result15->fetch_assoc()) {
                 $bookingIDSarray[] = $row['booking_id'];
        }
    } else {
        echo json_encode(['error' => 'Query execution failed']);
    }
}

if(isset($data['max_av']) && !empty($data['max_av'])){
    if(isset($data['max_av']) == "True"){
    $max_av = True;
    }
}

if(isset($data['recent_closure']) && !empty($data['recent_closure'])){
    if(isset($data['recent_closure']) == "True"){
    $recent_closure = True;
    }
}

$booking_records = array(); 

$page = isset($_GET['page']) ? max(1, $_GET['page']) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

if (!empty($bookingIDSarray)){
    $bookingIDString = implode(',', $bookingIDSarray);
    file_put_contents('header.txt', json_encode($bookingIDString));
    
$sql2 = "SELECT
    bd.*,
    bc.name,
    bc.number,
    p.project_name,
    osr.status_id,
    osr.expected,
    osr.completed,
    bd.client_id,
    bd.ladder_stage,
    bd.base_brokerage,
    bd.kicker_percent,
    bd.kicker_value,
    bd.ei_percent,
    bd.ei_value
FROM
    booking_details bd
JOIN booked_clients bc ON
    bd.client_id = bc.User_id
JOIN project p ON
    bd.project_id = p.project_id
JOIN ob_status_records osr ON
    bd.os_status_id = osr.ob_record_id
    WHERE bd.booking_id IN ($bookingIDString)";
    
$result2 = $conn->query($sql2);

if($result2){
    $totalCount = mysqli_num_rows($result2);
     if ($page * $limit > $totalCount) {
        $limit = $totalCount % $limit;
     }
}

$fetched_ladder_percent = null;
$fetched_kicker_percent = null;
$fetched_ei_percent = null;
$fetched_brokerage_percent = null;
$developer_name = null;
$location_name = null;
$developer_name = null;

$sql = "SELECT
    bd.*,
    bc.name,
    bc.number,
    p.project_name,
    osr.status_id,
    osr.expected,
    osr.completed,
    bd.client_id,
    bd.ladder_stage,
    bd.base_brokerage,
    bd.kicker_percent,
    bd.kicker_value,
    bd.ei_percent,
    bd.ei_value
FROM
    booking_details bd
JOIN booked_clients bc ON
    bd.client_id = bc.User_id
JOIN project p ON
    bd.project_id = p.project_id
JOIN ob_status_records osr ON
    bd.os_status_id = osr.ob_record_id
    WHERE bd.booking_id IN ($bookingIDString)";
    
if ($max_av) {
    $sql .= " ORDER BY bd.agreement_value DESC";
}

if ($recent_closure) {
    $sql .= " ORDER BY bd.closure_date DESC";
}

$sql .= " LIMIT $limit OFFSET $offset";

$result = $conn->query($sql);


if (!$result) {
    die("Query failed: " . $conn->error);
}


$booking_records['total_count'] = ['count' => $totalCount];


while ($row = $result->fetch_assoc()) {
    $generic_details = array(
        "booking_id" => $row["booking_id"],
        "client_id" => $row["client_id"],
        "project_id" => $row["project_id"],
        "wing" => $row["wing"],
        "flat_no" => $row["flat_no"],
        "configuration_id" => $row["configuration_id"],
        "carpet_area" => $row["carpet_area"],
        "closure_date" => $row["closure_date"],
        "closed_by" => $row["closed_by"],
        "sourced_by" => $row["sourced_by"],
        "cashback_amount" => $row["cashback_amount"],
        "agreement_value" => $row["agreement_value"],
        "csop" => $row["csop"],
        "name" => $row["name"],
        "number" => $row["number"],
        "project_name" => $row["project_name"]
    );

    $ob_status_details = array(
        "os_status_id" => $row["os_status_id"],
        "status_id" => $row["status_id"],
        "expected" => $row["expected"],
        "completed" => $row["completed"]
    );

    

    $project_id = $row["project_id"];
    $closure_date = $row["closure_date"];
    $booking_id = $row["booking_id"];
    $client_id = $row["client_id"];
    $fetched_ladder_percent = $row["ladder_stage"];
    $fetched_brokerage_percent = $row['base_brokerage'];
    $fetched_kicker_percent = $row['kicker_percent'];
    $fetched_kicker_value = $row['kicker_value'];
    $fetched_ei_percent = $row["ei_percent"];
    $fetched_ei_value = $row['ei_value'];
    
    

   //FETCH THE LOCATION AND DEVELOPER_NAME 
    if ($project_id !== null) {
    
        $developer_sql = "SELECT c.company_name, d.developer_name, l.location_name FROM project AS p JOIN company AS c 
                          ON p.company_id = c.company_id JOIN developer AS d ON c.developer_id = d.developer_id 
                          JOIN location AS l ON d.location_id = l.location_id WHERE p.project_id = '$project_id'";
        $result_developer_name = $conn->query($developer_sql);
        if ($result_developer_name) {
            while ($result_row = $result_developer_name->fetch_assoc()) {
                $developer_name = $result_row['developer_name'];
                $company_name = $result_row['company_name'];
                $location_name = $result_row['location_name'];
                        }
                    }
                
    }
    
    //GET THE MOST RECENT FOLLOWUP 
    $followupSQL = "SELECT booking_id, MAX(followup_date) AS most_recent_followup_date, followup_for FROM followups WHERE booking_id = '$booking_id' GROUP BY booking_id, followup_type LIMIT 1";
    $followupResult = $conn->query($followupSQL);
    if($followupResult){
        while ($resultFollowuprow = $followupResult->fetch_assoc()){
            $generic_details["recent_type"] = $resultFollowuprow["followup_for"];
            $generic_details["recent_date"] = $resultFollowuprow["most_recent_followup_date"];
        }
    }
    
    
    //GET THE INVOICE COUNT
    $invoiceCountSQL = "SELECT COUNT(*) AS inv_count FROM invoice WHERE `client_id` = '$client_id' ";
    $invoiceCountResult = $conn->query($invoiceCountSQL);
    if($invoiceCountResult){
        while ($invoiceCountRow = $invoiceCountResult->fetch_assoc()) {
            $generic_details["inv_count"] = $invoiceCountRow['inv_count'];
        }
    }
    


    // Create a booking record array
    $booking_record = array(
        'generic_details' => $generic_details,
        'ob_status_details' => $ob_status_details,
        'fetched_ladder_percent' => $fetched_ladder_percent,
        'fetched_kicker_percent' => $fetched_kicker_percent,
        'kicker_value' => $fetched_kicker_value,
        'ei_value' => $fetched_ei_value,
        'fetched_ei_percent' => $fetched_ei_percent,
        'fetched_brokerage_percent' => $fetched_brokerage_percent,
        'company_name' => $company_name,
        'developer_name' => $developer_name,
        'location_name' => $location_name
    );

    $booking_records[] = $booking_record;
}
$booking_records = array_values($booking_records);


header("Content-Type: application/json");
echo json_encode($booking_records);

    
}

else if (empty($bookingIDSarray)){

$fetched_ladder_percent = null;
$fetched_kicker_percent = null;
$fetched_ei_percent = null;
$fetched_brokerage_percent = null;
$developer_name = null;
$location_name = null;
$developer_name = null;
$max_av = False;
$recent_closure = False;

if(isset($data['max_av']) && !empty($data['max_av'])){
    if(isset($data['max_av']) == "True"){
    $max_av = True;
    }
}
if(isset($data['recent_closure']) && !empty($data['recent_closure'])){
    $recent_closure = True;
}

//INNER JOIN
$sql = "SELECT
    bd.*,
    bc.name,
    bc.number,
    p.project_name,
    osr.status_id,
    osr.expected,
    osr.completed,
    bd.client_id,
    bd.ladder_stage,
    bd.base_brokerage,
    bd.kicker_percent,
    bd.kicker_value,
    bd.ei_percent,
    bd.ei_value
FROM
    booking_details bd
JOIN booked_clients bc ON
    bd.client_id = bc.User_id
JOIN project p ON
    bd.project_id = p.project_id
JOIN ob_status_records osr ON
    bd.os_status_id = osr.ob_record_id";

// Add conditional ordering
if ($max_av) {
    $sql .= " ORDER BY bd.agreement_value DESC";
} elseif ($recent_closure) {
    $sql .= " ORDER BY bd.closure_date DESC";
}

// Add LIMIT and OFFSET
$sql .= " LIMIT $limit OFFSET $offset";



$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}

$booking_records = array();


$countSql = "SELECT COUNT(*) AS total_count FROM booking_details";
$countResult = $conn->query($countSql);
if ($countResult) {
    $countRow = $countResult->fetch_assoc();
    $totalCount = $countRow['total_count'];
} else {
    die("Count query failed: " . $conn->error);
}

 $countResult = $conn->query($countSql);
    if ($countResult) {
        $countRow = $countResult->fetch_assoc();
        $totalCount = $countRow['total_count'];
    } else {
        die("Count query failed: " . $conn->error);
    }
    
    if ($page * $limit > $totalCount) {
    $limit = $totalCount % $limit;
}

$booking_records['total_count'] = ['count' => $totalCount];


//remove while loop and return the single row as an array in a variable
while ($row = $result->fetch_assoc()) {
    
    $generic_details = array(
        "booking_id" => $row["booking_id"],
        "client_id" => $row["client_id"],
        "project_id" => $row["project_id"],
        "wing" => $row["wing"],
        "flat_no" => $row["flat_no"],
        "configuration_id" => $row["configuration_id"],
        "carpet_area" => $row["carpet_area"],
        "closure_date" => $row["closure_date"],
        "closed_by" => $row["closed_by"],
        "sourced_by" => $row["sourced_by"],
        "cashback_amount" => $row["cashback_amount"],
        "agreement_value" => $row["agreement_value"],
        "csop" => $row["csop"],
        "name" => $row["name"],
        "number" => $row["number"],
        "project_name" => $row["project_name"]
    );

    $ob_status_details = array(
        "os_status_id" => $row["os_status_id"],
        "status_id" => $row["status_id"],
        "expected" => $row["expected"],
        "completed" => $row["completed"]
    );

    

    $project_id = $row["project_id"];
    $closure_date = $row["closure_date"];
    $booking_id = $row["booking_id"];
    $client_id = $row["client_id"];


    $percentageSQL = "SELECT ladder_stage AS ladder_percent , base_brokerage , kicker_percent , ei_percent FROM booking_details WHERE booking_id = $booking_id";
    $resultPercentSQL = $conn->query($percentageSQL);
    if($resultPercentSQL){
        while($resultPercentrow = $resultPercentSQL->fetch_assoc()){
            $fetched_ladder_percent = $resultPercentrow["ladder_percent"];
            $fetched_kicker_percent = $resultPercentrow["kicker_percent"];
            $fetched_brokerage_percent = $resultPercentrow["base_brokerage"];
            $fetched_ei_percent = $resultPercentrow["ei_percent"];
            $fetched_ei_value = $row['ei_value'];
            $fetched_kicker_value = $row['kicker_value'];
        }
    }
    
    $followupSQL = "SELECT booking_id, MAX(followup_date) AS most_recent_followup_date, MAX(followup_for) AS followup_for FROM followups WHERE booking_id = '$booking_id' GROUP BY booking_id, followup_type LIMIT 1";
    $followupResult = $conn->query($followupSQL);
    if($followupResult){
        while ($resultFollowuprow = $followupResult->fetch_assoc()){
            $generic_details["recent_type"] = $resultFollowuprow["followup_for"];
            $generic_details["recent_date"] = $resultFollowuprow["most_recent_followup_date"];
        }
    }
    
     //GET THE INVOICE COUNT
    $invoiceCountSQL = "SELECT COUNT(*) AS inv_count FROM invoice WHERE `client_id` = '$client_id' ";
    $invoiceCountResult = $conn->query($invoiceCountSQL);
    if($invoiceCountResult){
        while ($invoiceCountRow = $invoiceCountResult->fetch_assoc()) {
            $generic_details["inv_count"] = $invoiceCountRow['inv_count'];
        }
    }

   //FETCH THE LOCATION AND DEVELOPER_NAME 
    if ($project_id !== null) {
    
        $developer_sql = "SELECT c.company_name, d.developer_name, l.location_name FROM project AS p JOIN company AS c 
                          ON p.company_id = c.company_id JOIN developer AS d ON c.developer_id = d.developer_id 
                          JOIN location AS l ON d.location_id = l.location_id WHERE p.project_id = '$project_id'";
        $result_developer_name = $conn->query($developer_sql);
        if ($result_developer_name) {
            while ($result_row = $result_developer_name->fetch_assoc()) {
                $developer_name = $result_row['developer_name'];
                $company_name = $result_row['company_name'];
                $location_name = $result_row['location_name'];
                        }
                    }
                
    }



    // Create a booking record array
    $booking_record = array(
        'generic_details' => $generic_details,
        'ob_status_details' => $ob_status_details,
        'fetched_ladder_percent' => $fetched_ladder_percent,
        'fetched_kicker_percent' => $fetched_kicker_percent,
        'kicker_value' => $fetched_kicker_value,
        'ei_value' => $fetched_ei_value,
        'fetched_ei_percent' => $fetched_ei_percent,
        'fetched_brokerage_percent' => $fetched_brokerage_percent,
        'company_name' => $company_name,
        'developer_name' => $developer_name,
        'location_name' => $location_name,
    );


    // Add the booking record to the array of booking records
    $booking_records[] = $booking_record;
}



// Close the database connection
$conn->close();

// Return the array of booking records as JSON
header("Content-Type: application/json");
echo json_encode(array_values($booking_records));
}


else{
    echo json_encode([]);
}





?>